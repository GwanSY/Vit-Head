/*
HE instance
- Only support BFV for now
*/
#ifndef HE_H__
#define HE_H__

#include "LinearHE/evaluator-wrapper.h"
#include "LinearHE/utils-HE.h"
#include <ckks.h>
#include <fstream>
#include <iostream>
#include <thread>
#include <math.h>
#include <algorithm>

using namespace sci;
using namespace std;
using namespace seal;

template <typename T>
T EncodeToFxp(double x, int fxp) {
  T u = std::roundf(std::abs(x) * static_cast<double>(1L << fxp));
  if (std::signbit(x)) {
    return -u;
  }
  return u;
}

class HE
{
public:

    int party;
    sci::NetIO *io;

    size_t poly_modulus_degree;
    uint64_t plain_mod;
    // plain_mod / 2
    uint64_t plain_mod_2;

    SEALContext *context;
	Encryptor *encryptor;
	Decryptor *decryptor;
	Evaluator *evaluator;
	BatchEncoder *encoder;
	GaloisKeys *gal_keys;
	RelinKeys *relin_keys;
	Ciphertext *zero;

    HE();
    HE(int party,
        sci::NetIO* io,
        size_t poly_modulus_degree, 
        vector<int> coeff_bit_sizes, 
        uint64_t plain_mod);
    HE(int party,
        sci::NetIO* io,
        size_t poly_modulus_degree, 
        vector<int> coeff_bit_sizes, 
        uint64_t plain_mod_bit, bool bit);

    ~HE();
	
};

class HE_CKKS
{
public:
    using scalar_t = uint64_t;
	using complex_t = std::complex<scalar_t>;
    using wide_scalar_t = __uint128_t;
    struct wide_complex_t {
        wide_scalar_t real = 0;
        wide_scalar_t imag = 0;
    };
    using complex_double = std::complex<double>;
    // using MPCArith = seal::util::Arithmetic<complex_t, complex_t, scalar_t>;
    using FFTHandler = seal::util::DWTHandler<complex_t, complex_t, scalar_t>;
    int party;
    sci::NetIO *io;
    vector<std::size_t> matrix_reps_index_map_;
	vector<complex_double> root_powers_2n;
  	vector<complex_double> inv_root_powers_2n;
    vector<complex_t> root_powers_2n_scaled;
  	vector<complex_t> inv_root_powers_2n_scaled;
    std::vector<complex_t> encode_mat_;
    std::vector<complex_t> decode_mat_;
	vector<complex_double> root_powers_n;
  	vector<complex_double> inv_root_powers_n;
    
    size_t poly_modulus_degree;
    size_t num_slots;
    // fft_scale是mpc的scale，he_scale是he的scale，he_scale由EVA在MSE<1e-11情况下得到
    int fft_scale;
    int he_scale;
    LOCATION backend_;

    // MPCArith mpc_arith_;
    FFTHandler fft_handler_;
    // uint64_t plain_mod;
    SEALContext *context;
	Encryptor *encryptor;
	Decryptor *decryptor;
	Evaluator *evaluator;
	CKKSEncoder *encoder;
	GaloisKeys *gal_keys = new GaloisKeys();
	RelinKeys *relin_keys = new RelinKeys();
	Ciphertext *zero;

	PhantomContext *dcontext = nullptr;
	PhantomCKKSEncoder *dencoder = nullptr;
	PhantomRelinKey *drelin_keys = nullptr;
	PhantomGaloisKey *dgal_keys = nullptr;
	PhantomEvaluator *devaluator = nullptr;

    /** [Important]
        `iunit` is only used in `imag_repack`.
        Assume that `iunit` is only used in highest level.
     */
    const UnifiedPlaintext iunit;

    HE_CKKS(int party,
        sci::NetIO* io,
        size_t poly_modulus_degree, 
        vector<int> modulus_bits,int fft_scale,int he_scale,
        LOCATION backend)
            : iunit(backend == LOCATION::DEVICE ? LOCATION::HOST_AND_DEVICE : backend) {
        this->party = party;
        this->poly_modulus_degree = poly_modulus_degree;
        this->io = io;
        this->fft_scale = fft_scale;
        this->he_scale = he_scale;
        this->backend_ = backend;
        // set index map and root map
        int logn = std::log2(poly_modulus_degree);
        this->num_slots = poly_modulus_degree >> 1;
        matrix_reps_index_map_.resize(poly_modulus_degree);
        uint64_t gen = generator_of_ZZm;
        uint64_t pos = 1;
        //此处获取2n次原根
        uint64_t m = static_cast<uint64_t>(poly_modulus_degree) << 1;
        cout << m << endl;
        // `pos` is a recurrence (pos_{i+1} = gen * pos_i mod 2N), so this
        // loop must remain sequential. Parallelising it races both reads and
        // writes of `pos` and can give the two MPC parties different CKKS
        // slot permutations.
        for (size_t i = 0; i < num_slots; i++)
        {
            // Position in normal bit order
            uint64_t index1 = (pos - 1) >> 1;
            uint64_t index2 = (m - pos - 1) >> 1;

            // Set the bit-reversed locations
            matrix_reps_index_map_[i] = seal::util::safe_cast<size_t>(seal::util::reverse_bits(index1, logn));
            matrix_reps_index_map_[num_slots | i] = seal::util::safe_cast<size_t>(seal::util::reverse_bits(index2, logn));

            // Next primitive root
            pos *= gen;
            pos &= (m - 1);
        }
        // root_powers_2n.resize(poly_modulus_degree);
        // inv_root_powers_2n.resize(poly_modulus_degree);
        root_powers_2n_scaled.resize(poly_modulus_degree);
        inv_root_powers_2n_scaled.resize(poly_modulus_degree);

        // fft_scale is 40 for the paper's CKKS<->MPC path.  Keep the
        // scale factor in an unsigned 64-bit expression: `1 << fft_scale`
        // is an int shift and therefore overflows before it is converted to
        // scalar_t, making every fixed-point root zero at fft_scale=40.
        const scalar_t fft_scale_factor =
            (fft_scale >= 0 && fft_scale < 64)
                ? (scalar_t{1} << fft_scale)
                : throw invalid_argument("invalid CKKS FFT scale");
        // root_powers_n.resize(poly_modulus_degree);
        // inv_root_powers_n.resize(poly_modulus_degree);

        seal::util::ComplexRoots complex_roots_2n(static_cast<size_t>(m),
                                            seal::MemoryManager::GetPool());
        // seal::util::ComplexRoots complex_roots_n(static_cast<size_t>(poly_modulus_degree),
        //                                     seal::MemoryManager::GetPool());
        #pragma omp parallel for num_threads(64)
        for (size_t i = 1; i < poly_modulus_degree; i++) {
            auto rp_2n = complex_roots_2n.get_root(seal::util::reverse_bits(i, logn));
            // auto rp_n = complex_roots_n.get_root(seal::util::reverse_bits(i, logn));

            // auto rp_2n = complex_roots_2n.get_root(i);
            // auto rp_n = complex_roots_n.get_root(i);

            // root_powers_2n[i].real(rp_2n.real());
            // root_powers_2n[i].imag(rp_2n.imag());
            // root_powers_n[i].real(rp_n.real());
            // root_powers_n[i].imag(rp_n.imag());

            root_powers_2n_scaled[i].real(
                static_cast<scalar_t>(rp_2n.real() * fft_scale_factor));
            root_powers_2n_scaled[i].imag(
                static_cast<scalar_t>(rp_2n.imag() * fft_scale_factor));

            auto inv_rp_2n = std::conj(complex_roots_2n.get_root(seal::util::reverse_bits(i - 1, logn) + 1));
            
            // auto inv_rp_n = std::conj(complex_roots_n.get_root(seal::util::reverse_bits(i - 1, logn) + 1));
            // auto inv_rp_2n = std::conj(complex_roots_2n.get_root(i));
            // auto inv_rp_n = std::conj(complex_roots_n.get_root(i));

            // inv_root_powers_2n[i].real(inv_rp_2n.real());
            // inv_root_powers_2n[i].imag(inv_rp_2n.imag());
            inv_root_powers_2n_scaled[i].real(
                static_cast<scalar_t>(inv_rp_2n.real() * fft_scale_factor));
            inv_root_powers_2n_scaled[i].imag(
                static_cast<scalar_t>(inv_rp_2n.imag() * fft_scale_factor));
            
            // inv_root_powers_n[i].real(inv_rp_n.real());
            // inv_root_powers_n[i].imag(inv_rp_n.imag());
            // if(i==2){
            //   std::cout << inv_root_powers_[i].real() << std::endl;
            // }
        }
        // decode_mat_.resize(this->num_slots * this->poly_modulus_degree);
        // encode_mat_.resize(this->poly_modulus_degree * this->num_slots);
        // cout << "ok1" << endl;
        // uint64_t gen_pow = 1;
        // #pragma omp parallel for num_threads(64)
        // for (size_t r = 0; r < this->num_slots; r++) {
        //     #pragma omp parallel for num_threads(64)
        //     for (size_t c = 0; c < this->poly_modulus_degree; c++) {
        //         // V[r, c] = w^{5^r * c}
        //         auto v = complex_roots_2n.get_root((gen_pow * c) & (m - 1));
        //         decode_mat_[r * poly_modulus_degree + c].real(EncodeToFxp<scalar_t>(v.real(), fft_scale));
        //         decode_mat_[r * poly_modulus_degree + c].imag(EncodeToFxp<scalar_t>(v.imag(), fft_scale));
        //         // transpose V^T
        //         encode_mat_[c * num_slots + r].real(EncodeToFxp<scalar_t>(v.real(), fft_scale));
        //         encode_mat_[c * num_slots + r].imag(EncodeToFxp<scalar_t>(v.imag(), fft_scale));
        //     }
        //     gen_pow *= gen;
        //     gen_pow &= (m - 1);
        // }
        
        // mpc_arith_ = MPCArith();
        auto mpc_arith_ = seal::util::Arithmetic<complex_t, complex_t, scalar_t>(fft_scale);
        fft_handler_ = seal::util::DWTHandler<complex_t, complex_t, scalar_t>(mpc_arith_);

        EncryptionParameters hparms(scheme_type::ckks);
        auto hmodulus = seal::CoeffModulus::Create(poly_modulus_degree, modulus_bits);
        hparms.set_poly_modulus_degree(poly_modulus_degree);
        hparms.set_coeff_modulus(hmodulus);
        // cout << "seal modulus:" << endl;
        // for (auto &v : dmodulus) {
        //     cout << std::hex << v.value() << " ";
        // }
        // cout << std::dec << endl;
        // FIXME: Assuming that SEAL and Phantom generate the same parameters
        context = new SEALContext(hparms, true, seal::sec_level_type::tc128);
        cout << " ok3" << endl;
        encoder = new CKKSEncoder(*context);
        evaluator = new Evaluator(*context);

        // Initialize const plaintext iunit
        const vector<complex<double>> iunit_vec1(encoder->slot_count(), {0.0, 1.0});
        encoder->encode(
            iunit_vec1,
            context->first_parms_id(),
            1.0, /* scale = 1.0, no need to rescale */
            *const_cast<UnifiedPlaintext *>(&iunit));

        if (is_gpu_enable()) {
            phantom::EncryptionParameters dparms(phantom::scheme_type::ckks);
            auto dmodulus = phantom::arith::CoeffModulus::Create(poly_modulus_degree, modulus_bits);
            // cout << "phantom modulus:" << endl;
            // for (auto &v : hmodulus) {
            //     cout << std::hex << v.value() << " ";
            // }
            // cout << std::dec << endl;
            dparms.set_poly_modulus_degree(poly_modulus_degree);
            dparms.set_coeff_modulus(dmodulus);
            dcontext = new PhantomContext(dparms);
            dencoder = new PhantomCKKSEncoder(*dcontext);
            devaluator = new PhantomEvaluator(*dcontext);

            // Initialize const plaintext iunit
            const vector<cuDoubleComplex> iunit_vec2(encoder->slot_count(), {0.0, 1.0});
            dencoder->encode(
                *dcontext,
                iunit_vec2,
                1.0, /* scale = 1.0, no need to rescale */
                *const_cast<UnifiedPlaintext *>(&iunit),
                dcontext->first_context_data().chain_index());
        }

        if (party == sci::BOB) { // BOB, client
            KeyGenerator keygen(*context);
            SecretKey sec_key = keygen.secret_key();
            PublicKey pub_key;
            keygen.create_public_key(pub_key);
            GaloisKeys gal_keys_;
            keygen.create_galois_keys(gal_keys_);
            RelinKeys relin_keys_;
            keygen.create_relin_keys(relin_keys_);

            stringstream os;
            pub_key.save(os);
            uint64_t pk_size = os.tellp();
            gal_keys_.save(os);
            uint64_t gk_size = (uint64_t)os.tellp() - pk_size;
            relin_keys_.save(os);
            uint64_t rk_size = (uint64_t)os.tellp() - pk_size - gk_size;
            string keys_ser = os.str();
            io->send_data(&pk_size, sizeof(uint64_t));
            io->send_data(&gk_size, sizeof(uint64_t));
            io->send_data(&rk_size, sizeof(uint64_t));
            io->send_data(keys_ser.c_str(), pk_size + gk_size + rk_size);

            // stringstream os_sk;
            // sec_key.save(os_sk);
            // uint64_t sk_size = os_sk.tellp();
            // string keys_ser_sk = os_sk.str();
            // io->send_data(&sk_size, sizeof(uint64_t));
            // io->send_data(keys_ser_sk.c_str(), sk_size);

            encryptor = new Encryptor(*context, pub_key, sec_key);
            decryptor = new Decryptor(*context, sec_key);
            // vector<double> pod_matrix(poly_modulus_degree/2, 0ULL);
            // Plaintext tmp;
            // encoder->encode(pod_matrix,pow(2,20), tmp);
            // zero = new Ciphertext;
            // encryptor->encrypt(tmp, *zero);
            cout << "pk_size + gk_size + rk_size:" << pk_size + gk_size + rk_size << endl;
            cout << "BOB > HE instance initialized: " << endl;
        }
        else // party == ALICE, server
        {
            uint64_t pk_size;
            uint64_t gk_size;
            uint64_t rk_size;
            io->recv_data(&pk_size, sizeof(uint64_t));
            io->recv_data(&gk_size, sizeof(uint64_t));
            io->recv_data(&rk_size, sizeof(uint64_t));
            char *key_share = new char[pk_size + gk_size + rk_size];
            io->recv_data(key_share, pk_size + gk_size + rk_size);
            stringstream is;
            PublicKey pub_key;
            is.write(key_share, pk_size);
            pub_key.load(*context, is);
            gal_keys = new GaloisKeys();
            is.write(key_share + pk_size, gk_size);
            gal_keys->load(*context, is);
            relin_keys = new RelinKeys();
            is.write(key_share + pk_size + gk_size, rk_size);
            relin_keys->load(*context, is);
            delete[] key_share;

            // uint64_t sk_size;
            // io->recv_data(&sk_size, sizeof(uint64_t));
            // char *key_share_sk = new char[sk_size];
            // io->recv_data(key_share_sk, sk_size);
            // stringstream is_sk;
            // SecretKey sec_key;
            // is_sk.write(key_share_sk, sk_size);
            // sec_key.load(*context, is_sk);
            // delete[] key_share_sk;
            // decryptor = new Decryptor(*context, sec_key);
            encryptor = new Encryptor(*context, pub_key);
            cout << "pk_size + gk_size + rk_size:" << pk_size + gk_size + rk_size << endl;

            if (is_gpu_enable()) {
                // Load RelinKey to GPU
                auto start = high_resolution_clock::now();
                drelin_keys = new PhantomRelinKey();
                kswitchkey_to_device(*context, *relin_keys->data().data(),
                                     *dcontext, *drelin_keys);
                auto end = high_resolution_clock::now();
                auto load_time = (end - start).count() / 1e+6;
                cout << "load a relin key to gpu: " << load_time << " ms" << endl;

                // Load GaliosKey to GPU
                start = high_resolution_clock::now();
                dgal_keys = new PhantomGaloisKey();
                galoiskeys_to_device(*context, *gal_keys, *dcontext, *dgal_keys);
                end = high_resolution_clock::now();
                load_time = (end - start).count() / 1e+6;
                cout << "load galois keys to gpu: " << load_time << " ms" << endl;
            }

            cout << "ALICE > HE instance initialized: " << endl;
        }
        cout << "> HE instance initialized: " << endl;
        cout << "-> Poly Mod Degree: " << poly_modulus_degree << endl;
        cout << "-> Coeff Mod: " ;
        cout << "fft_scale: " << fft_scale << endl;
        for(auto mod: modulus_bits){
            cout << mod << " ";
        }
        cout << endl;
    }

    LOCATION backend() const { return backend_; }
    bool is_gpu_enable() const { return backend_ == LOCATION::DEVICE; }

    // Only the key-owning client can seed-compress fresh encryptions.
    // The ordinary ciphertext receiver expands SEAL's seed automatically;
    // evaluated/masked server ciphertexts must still use their full payload.
    template <class Plain, class Cipher>
    void encrypt_send(const vector<Plain> &plains, vector<Cipher> &ciphertexts) {
        if (party != sci::BOB || plains.empty() || plains.size() != ciphertexts.size())
            throw invalid_argument("seeded input encryption requires Bob and matching nonempty batches");
        vector<string> payloads(plains.size());
        const int workers = min<size_t>(16, plains.size());
#pragma omp parallel for num_threads(workers)
        for (int i = 0; i < static_cast<int>(plains.size()); ++i) {
            const auto &plain = static_cast<const Plaintext &>(plains[i]);
            auto seeded = encryptor->encrypt_symmetric(plain);
            stringstream stream;
            seeded.save(stream);
            payloads[i] = stream.str();
            // Preserve the caller's ciphertext buffer for existing metadata
            // checks and diagnostic consumers without changing their layout.
            stream.seekg(0);
            static_cast<Ciphertext &>(ciphertexts[i]).load(*context, stream);
        }
        uint64_t bytes = 0;
        for (const auto &payload : payloads) {
            const uint64_t size = payload.size();
            io->send_data(&size, sizeof(size));
            io->send_data(payload.data(), size);
            bytes += sizeof(size) + size;
        }
        cout << "CKKS_SEEDED_INPUT cts=" << plains.size()
             << " send_bytes=" << bytes << " secret_key_transferred=0" << endl;
    }

    vector<scalar_t> ckks_decode(vector<complex_t> x, int degree, bool half=false);

    // Paper Appendix C.4: decode in the extended Z_(2^(l+40)) ring and
    // perform the public-root truncations locally before the final scale
    // reduction.  This is the non-interactive counterpart of ckks_decode;
    // it is used only at the secure CKKS-to-MPC conversion boundary.
    vector<scalar_t> ckks_decode_wide(
        const vector<wide_complex_t> &x, int degree, int output_ell,
        int source_scale, int target_scale, bool half=false,
        int working_ell=-1) const;

    // Paper Algorithm 2 with Appendix C.3/C.4: the signed shares are
    // widened before the public inverse FFT, so every fixed-point FFT
    // truncation is performed in the extended ring rather than on a
    // 64-bit share.  The caller supplies the bit-reversed complex input.
    vector<wide_complex_t> ckks_encode_wide(
        const vector<wide_complex_t> &x, int degree, int working_ell=-1) const;

    vector<wide_complex_t> ckks_encode_wide(
        vector<wide_complex_t> &&x, int degree, int working_ell=-1) const;

    vector<scalar_t> ckks_encode(vector<scalar_t> x, int slot, bool half=false);

    void ckks_ntt(vector<scalar_t> x, int degree,double scale, Plaintext &destination);

    // Build a CKKS plaintext from coefficient residues that were converted
    // independently in every active RNS prime.  A single field residue must
    // never be copied into all limbs: additive shares are modulo each prime,
    // not modulo the product modulus.
    void ckks_ntt_rns(const vector<vector<scalar_t>> &rns_coefficients,
                      double scale, Plaintext &destination);

    vector<std::complex<HE_CKKS::scalar_t>> ckks_intt(const Plaintext &plain);

    void imag_repack(const UnifiedCiphertext &half, UnifiedCiphertext &real, UnifiedCiphertext &imag);

	// Complex* negative_cyclic_fft(Complex* x, int size);

	vector<complex_t> fft(vector<complex_t> x, int degree, bool use_matrix_mul);
	vector<complex_t> ifft(vector<complex_t> x, int degree, bool use_matrix_mul);

    // get Q of ct
    uint64_t get_Q(const Ciphertext &ct){
        // FIXME:
        const seal::SEALContext &context2 = context->get_context_data(ct.parms_id())->parms();
        auto &context_data = *context2.key_context_data();
        const uint64_t Q = *context_data.total_coeff_modulus();
        // cout << "modulus:" << *(cntxt->)
        return Q;
    }

    uint64_t get_logQ(const UnifiedCiphertext &ct){
        if (ct.location() == LOCATION::HOST) {
            auto &context_data = *context->get_context_data(ct.hcipher().parms_id());
            return context_data.total_coeff_modulus_bit_count();
        } else {
            auto &context_data = dcontext->get_context_data(ct.dcipher().chain_index());
            return context_data.total_coeff_modulus_bit_count();
        }
    }

    // get Q of pt
    uint64_t get_Q(const Plaintext &pt){
        // FIXME:
        const seal::SEALContext &context2 = context->get_context_data(pt.parms_id())->parms();
        auto &context_data = *context2.key_context_data();
        const uint64_t Q = *context_data.total_coeff_modulus();
        // cout << "modulus:" << *(cntxt->)
        return Q;
    }

    // get the default Q
    uint64_t get_Q(){
        const seal::SEALContext &context2 = context->get_context_data(context->first_parms_id())->parms();
        auto &context_data = *context2.key_context_data();
        const uint64_t Q = *context_data.total_coeff_modulus();
        // cout << "modulus:" << *(cntxt->)
        return Q;
    }

    // The secure MPC->CKKS adapter is a field conversion into the final
    // single-prime CKKS plaintext ring (Appendix C.3).  The default get_Q()
    // above intentionally returns the key-context product and is therefore
    // not the modulus used at this boundary.
    uint64_t get_conversion_prime() const {
        if (context == nullptr || context->last_context_data() == nullptr) {
            throw runtime_error("CKKS conversion context is unavailable");
        }
        const auto &modulus =
            context->last_context_data()->parms().coeff_modulus();
        if (modulus.size() != 1) {
            throw runtime_error(
                "CKKS conversion requires the final single-prime level");
        }
        return modulus.back().value();
    }

    inline void print_parameters(const seal::SEALContext &context)
    {
        auto &context_data = *context.key_context_data();
        /*
        Which scheme are we using?
        */
        std::string scheme_name;
        switch (context_data.parms().scheme())
        {
        case seal::scheme_type::bfv:
            scheme_name = "BFV";
            break;
        case seal::scheme_type::ckks:
            scheme_name = "CKKS";
            break;
        case seal::scheme_type::bgv:
            scheme_name = "BGV";
            break;
        default:
            throw std::invalid_argument("unsupported scheme");
        }
        std::cout << "/" << std::endl;
        std::cout << "| Encryption parameters :" << std::endl;
        std::cout << "|   scheme: " << scheme_name << std::endl;
        std::cout << "|   poly_modulus_degree: " << context_data.parms().poly_modulus_degree() << std::endl;

        /*
        Print the size of the true (product) coefficient modulus.
        */
        std::cout << "|   coeff_modulus size: ";
        std::cout << context_data.total_coeff_modulus_bit_count() << " (";
        auto coeff_modulus = context_data.parms().coeff_modulus();
        std::size_t coeff_modulus_size = coeff_modulus.size();
        for (std::size_t i = 0; i < coeff_modulus_size - 1; i++)
        {
            std::cout << coeff_modulus[i].bit_count() << " + ";
        }
        std::cout << coeff_modulus.back().bit_count();
        std::cout << ") bits" << std::endl;

        std::cout << "|   coeff_modulus : ";
        std::cout <<  " (";
        for (std::size_t i = 0; i < coeff_modulus_size; i++)
        {
            //coeff_modulus[i].data()返回的是value的pointer
            std::cout << *coeff_modulus[i].data() << " + ";
        }
        std::cout << ") " << std::endl;
        /*
        For the BFV scheme print the plain_modulus parameter.
        */
        if (context_data.parms().scheme() == seal::scheme_type::bfv)
        {
            std::cout << "|   plain_modulus: " << context_data.parms().plain_modulus().value() << std::endl;
        }

        std::cout << "\\" << std::endl;
    }
};
#endif
