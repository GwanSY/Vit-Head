# 实验结果入口

- 当前研究二：[research2/](research2/)，统一日志为 [experiment_01/run.log](research2/experiment_01/run.log)。
- 当前成本输入：[research2/inputs/](research2/inputs/)。缺项与来源记录见 `cost_sources.json`。
- baseline / paper 记录：[paper/](paper/)。具体 baseline 以执行层数、配置、二进制和计时口径为准，不仅看目录名或 PASS。
- 异构完整运行及成本来源：[a3_a4_review/](a3_a4_review/)。
- 历史完整组合成本：[20260903_two_budget_measurements/](20260903_two_budget_measurements/)。不要与不同配置的当前 GPU 7 成本混用。

2026-09-09 的历史结果整理清单见 [CLEANUP_PLAN.md](../archives/outputs-20260909-103531/CLEANUP_PLAN.md)。清单内的 232 项历史原副本已经用户确认并删除，归档保留；baseline 和成本引用记录仍在原位。新实验请继续写入 `research2/`，避免新增散落在本目录的时间戳目录。
