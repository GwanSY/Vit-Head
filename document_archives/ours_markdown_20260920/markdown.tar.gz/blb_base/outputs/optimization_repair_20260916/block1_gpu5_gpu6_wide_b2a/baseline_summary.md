# BLB ViT-B/16 secure inference measurement

Protocol: original BLB CKKS + MPC/VOLE; no protocol substitution.

- Packing: **197 logical tokens → 256 physical rows**
- Executed Transformer blocks: **1**
- Secure end-to-end: **87.849518 s**
- Communication (Alice+Bob): **5480703008 bytes (5.480703 GB)**
- HE internal counter: **14.572283 s**
- Conversion internal counter: **25.904308 s**
- H2D internal counter: **0.047594 s**
- Phantom plaintext encode: **14.107939 s**
- Phantom plaintext release: **0.000000 s**
- D2H internal counter: **0.009988 s**
- MPC nonlinear wall buckets: **17.935986 s**

The nonlinear bucket is diagnostic and overlaps the prescribed HE/conversion boundaries inside LayerNorm; it is not added to the other counters.

| Stage | 1-block wall time (s) | Alice+Bob send bytes |
|---|---:|---:|
| QKV | 3.176224 | 57675348 |
| QK^T | 8.638918 | 0 |
| CKKS_to_MPC | 20.309409 | 598452224 |
| Softmax | 15.522245 | 385395302 |
| MPC_to_CKKS | 10.227063 | 236705792 |
| Softmax_x_V | 5.586414 | 0 |
| Output_Projection | 1.068015 | 6293196 |
| LayerNorm1 | 1.331356 | 102436672 |
| FFN1 | 5.118532 | 66267537 |
| GELU | 4.311827 | 141572096 |
| FFN2 | 11.017316 | 69231336 |
| LayerNorm2 | 1.542200 | 102436672 |

- Full counters: `baseline_summary.csv`
- Per-block counters: `block_profile_alice_plus_bob.csv`
- Per-block stage timeline: `block_online_breakdown_alice_plus_bob.csv`
