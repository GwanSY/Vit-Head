# BLB ViT-B/16 secure inference measurement

Protocol: original BLB CKKS + MPC/VOLE; no protocol substitution.

- Packing: **197 logical tokens → 256 physical rows**
- Executed Transformer blocks: **12**
- Secure end-to-end: **899.687325 s**
- Communication (Alice+Bob): **25571575474 bytes (25.571575 GB)**
- HE internal counter: **136.273230 s**
- Conversion internal counter: **270.837590 s**
- H2D internal counter: **0.603017 s**
- Phantom plaintext encode: **112.252002 s**
- Phantom plaintext release: **0.000000 s**
- D2H internal counter: **0.104174 s**
- MPC nonlinear wall buckets: **210.581287 s**

The nonlinear bucket is diagnostic and overlaps the prescribed HE/conversion boundaries inside LayerNorm; it is not added to the other counters.

| Stage | 12-block wall time (s) | Alice+Bob send bytes |
|---|---:|---:|
| QKV | 41.499957 | 692102853 |
| QK^T | 66.873848 | 0 |
| CKKS_to_MPC | 193.776881 | 7159198848 |
| Softmax | 179.475640 | 4734364921 |
| MPC_to_CKKS | 107.599508 | 2953479616 |
| Softmax_x_V | 67.092029 | 0 |
| Output_Projection | 9.572702 | 75518352 |
| LayerNorm1 | 17.721978 | 1249939936 |
| FFN1 | 52.413065 | 795218959 |
| GELU | 55.671201 | 1753132384 |
| FFN2 | 77.555481 | 830776032 |
| LayerNorm2 | 16.702702 | 1250499392 |

- Full counters: `baseline_summary.csv`
- Per-block counters: `block_profile_alice_plus_bob.csv`
- Per-block stage timeline: `block_online_breakdown_alice_plus_bob.csv`
