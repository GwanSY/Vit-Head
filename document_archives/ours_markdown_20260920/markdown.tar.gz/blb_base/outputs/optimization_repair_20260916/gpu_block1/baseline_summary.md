# BLB ViT-B/16 secure inference measurement

Protocol: original BLB CKKS + MPC/VOLE; no protocol substitution.

- Packing: **197 logical tokens → 256 physical rows**
- Executed Transformer blocks: **1**
- Secure end-to-end: **88.707191 s**
- Communication (Alice+Bob): **5492844735 bytes (5.492845 GB)**
- HE internal counter: **10.113049 s**
- Conversion internal counter: **29.412400 s**
- H2D internal counter: **0.043489 s**
- Phantom plaintext encode: **9.041695 s**
- Phantom plaintext release: **0.000000 s**
- D2H internal counter: **0.009270 s**
- MPC nonlinear wall buckets: **26.126033 s**

The nonlinear bucket is diagnostic and overlaps the prescribed HE/conversion boundaries inside LayerNorm; it is not added to the other counters.

| Stage | 1-block wall time (s) | Alice+Bob send bytes |
|---|---:|---:|
| QKV | 2.936030 | 57675914 |
| QK^T | 5.185490 | 0 |
| CKKS_to_MPC | 21.024754 | 609467392 |
| Softmax | 17.853463 | 385394121 |
| MPC_to_CKKS | 13.268411 | 236705792 |
| Softmax_x_V | 5.576311 | 0 |
| Output_Projection | 0.707743 | 6293196 |
| LayerNorm1 | 1.564831 | 102436672 |
| FFN1 | 3.961668 | 66267691 |
| GELU | 8.539385 | 141572096 |
| FFN2 | 6.510005 | 69231336 |
| LayerNorm2 | 1.577651 | 102436672 |

- Full counters: `baseline_summary.csv`
- Per-block counters: `block_profile_alice_plus_bob.csv`
- Per-block stage timeline: `block_online_breakdown_alice_plus_bob.csv`
