# Conversion And Communication Repair, 2026-09-16

Status: **partial; the 498-second / aggregate 10-GB target is NOT achieved**.

Changes stay in OURS. BLB and lamination were not modified. There is one
production path, with no new fast/exact selector. No full12 inference was run.

## Measured Two-Block Result

Configuration: GPUs 4/6, GPU HE + CPU MPC, A0/all Softmax, 1 Gbps / 0.3 ms RTT,
64 OMP/MPC workers per party, 8 GPU streams. Final LayerNorm and classifier
are included; intermediate-observation diagnostics are disabled.

| Metric | Previous dual-GPU prefix | Current prefix |
| --- | ---: | ---: |
| Online time | 190.874233 s | 145.172347 s |
| Aggregate online sent bytes | 6,080,675,618 | 4,054,459,548 |
| Block 0 / block 1 | 91.7974 / 83.4387 s | 65.0792 / 62.8019 s |
| Second-block aggregate bytes | 2,716,498,267 | 1,780,409,998 |
| Secure / fixed / clear top-1 | 733 / 733 / 733 | 733 / 733 / 733 |
| Relative L2 versus fixed | 2.0543% | 1.8787% |
| Maximum absolute logit error | 0.01855469 | 0.01684570 |
| HE rotations | 101,262 | 101,246 |
| CKKS-to-MPC / MPC-to-CKKS ciphertexts | 318 / 510 | 310 / 494 |

Online time decreases 23.94%; aggregate online bytes decrease 33.32%.
Both parties' complete logits are identical. The existing prefix numerical
gate passes (top-1 equal, relative L2 <= 5%, maximum error <= 0.5).
This does not establish full-model or dataset accuracy.

Current setup/offline time is 204.280733 s; setup plus online is 349.453080 s.
These are not the online metric compared with 498.103927 s.

## Full-Model Forecast, Not Measurement

Formula: nonblock online time + first block + 11 times second block.
Traffic: prefix total + 10 times second-block aggregate traffic.

- Online: **773.191035 s (12.89 min)**.
- Aggregate online traffic: **21,858,559,528 bytes (21.86 GB)**.
- Target gate: **FAIL**. No full12 acceptance run was launched.

The second block alone spends 7.95 s on CKKS-to-MPC, 6.96 s on
MPC-to-CKKS, and 15.04 s in the Softmax profile stage. Its conversion
communication audit accounts for 819,319,296 aggregate bytes, about 46% of
the entire block's traffic. This remaining conversion/nonlinear work cannot
be removed merely by seed-compressing fresh ciphertexts. Native edge/cloud
dispatch still adds zero online messages.

## Implemented Repairs

- MPC-to-CKKS performs one secure slot extension. A signed integer FFT with
  sufficient workspace avoids a second coefficient-extension protocol.
  Per-prime RNS reduction is local; 40-bit sharing margin and 16 guard bits
  are retained.
- ViT Softmax removes public padded queries as well as masked keys, then
  restores exact zero padding without dropping valid tokens.
- Softmax broadcasts a securely bounded unsigned reciprocal with s+2 bits;
  the numerator/output ring stays unchanged. Generic/ReLU division remains
  wide.
- Fresh Bob inputs use standard SEAL seeded symmetric serialization.
  Alice reconstructs the random polynomial; Bob never transfers its secret
  key. Evaluated/masked server ciphertexts retain the full representation.
- Prefix logs now say full_structure=0 and executed_blocks=2. Future runner
  metadata points to the native runtime contract instead of a stale label.

Existing true real/imaginary output packing, BSGS, GPU streams, local residual
addition and LayerNorm inverse-sigma conversion reuse are retained.

## Validation And Operational Caveat

All seeded public tests pass: full signed-37-bit input range (49,152 values,
maximum error 0.572815 raw units), conversion roundtrip, compact Softmax
(maximum absolute error 0.000215837), native conversion/exp/reciprocal/
comparison fixtures. CPU wide-FFT, seven configuration tests and native
edge/cloud contract tests also pass. Build and shell syntax checks pass.

**The outer runner did not finish cleanly.** Editing a mounted shell script's
metadata line while its shell was waiting for inference caused an EOF/quote
error in its trailing commands. This was an agent operation error, not an
inference failure. Both /usr/bin/time resource files record exit status 0;
both native runtimes record complete PASS markers and all final metric/logit
files. Network cleanup restored noqueue, and the container no longer exists.
No extra inference was launched to hide or replace this run.

The original missing status.txt was not manufactured, and the stale
environment conversion_path label was not rewritten. The native contracts
and run metadata bind integer_lift_real_pairs_v3 and seeded_v1, and the binary
hash is recorded in assessment.json. The corrected shell scripts pass
bash -n; do not edit a live mounted runner during future experiments.

## Artifacts

- Current dual-GPU run: block2_gpu4_gpu6/
- Intermediate single-GPU run: block2_gpu6/ (not dual-GPU timing evidence)
- Seeded primitive regressions: seeded_public/
- Earlier primitive regressions: public/ and compact_public/
- Machine-readable metrics and limits: assessment.json
- Post-inference verification: block2_gpu4_gpu6/postrun_verification.json
- Prior dual-GPU baseline: ../fused_conversion_repair_20260916/block2_stream_order/
