# GPU 1 Full12 Attempts

Date: 2026-09-12. The user explicitly authorized GPU 1 for this run,
superseding its earlier exclusion for this task.

Requested workload: native edge/cloud OURS A4, 12 complete blocks,
train_6S0R6L public plan, both protocol parties sharing physical GPU 1,
group_packing=0, baseline_attention_packing=1, fast conversion, 8 GPU streams,
64 OpenMP threads per party, 1 Gbps / 0.3 ms RTT.

Candidate binary SHA-256:
`6c9aac1e37375f44f3cb1ad792fbdfb554f9609652a0248bb4cbf0b70ccaeb0a`.

## GPU Execution: Blocked

Both `gpu1_full12_01` and `gpu1_full12_02` passed the independent full-model
head-reorder oracle, then exited with code 75 at the GPU resource check.
Neither attempt started secure GPU inference. No secure logits, full GPU
latency, or numerical correctness result exists for these attempts.

GPU 1 was idle at the initial check on both occasions, but another Python
task started during the CPU prevalidation interval. The latest check showed
8425 MiB used, 72732 MiB free and 90% utilization (PID 2147006). No other
process was stopped and no busy-GPU override was enabled.

The blocked attempts' logs and config snapshots remain in their individual
directories. The active experiment config points to attempt 02, whose output
directory must not be reused on a later retry.

## Completed CPU Reference

Source: `gpu1_full12_01/reference_clear_fixed.json`.

- Full checkpoint execution: 12/12 blocks, no attention-only prefix.
- Float64 top-1: 248 (zero-based class index).
- Fixed-clear top-1: 248.
- 197-to-256 padding invariance: PASS, maximum valid-prefix difference 0.
- Float64 versus fixed-clear final logits: 1000 values, maximum absolute
  difference 1.7052982544563977, mean absolute difference 0.34251045212543224,
  RMSE 0.43419940522160483.

These are reference-versus-reference measurements, NOT secure GPU errors.
No dataset accuracy or preservation claim follows from this single input.

Single-GPU two-party execution is supported by the existing OURS runner.
Its timing must be reported separately from the historical 498.103927 s
original-BLB, all-Softmax, dual-A100 result. A run sharing GPU 1 with another
workload, if later authorized, must also be labeled contention-affected.
