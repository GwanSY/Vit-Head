# OURS ViT-B/16 real A3/A4 secure run

- Ablation: **A4**
- Attention packing: **unpacked**
- Structural path validation: **PASS**
- Secure end-to-end: **914.460734 s**
- Under 8 minutes: **FAIL**
- Setup + secure (slower party): **1187.165916 s**
- Communication (Alice + Bob): **32362230926 bytes**
- Head executions: Softmax=72, ReLU=0, Linear=72
- C2M=3940, M2C=5544, conversion ciphertexts=9484
- HE=176.693498 s, conversion=247.232490 s, MPC nonlinear bucket=330.215167 s
- Numerical accuracy: **BLOCKED by paused/failed A0**; matching party predictions are not an accuracy claim.
