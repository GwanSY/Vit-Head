# OURS ViT-B/16 real A3/A4 secure run

- Ablation: **A4**
- Attention packing: **unpacked**
- Structural path validation: **PASS**
- Secure end-to-end: **908.940727 s**
- Under 8 minutes: **FAIL**
- Setup + secure (slower party): **1190.201502 s**
- Communication (Alice + Bob): **32362226183 bytes**
- Head executions: Softmax=72, ReLU=0, Linear=72
- C2M=3940, M2C=5544, conversion ciphertexts=9484
- HE=178.396881 s, conversion=245.891131 s, MPC nonlinear bucket=332.413881 s
- Numerical accuracy: **BLOCKED by paused/failed A0**; matching party predictions are not an accuracy claim.
