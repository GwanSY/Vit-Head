# OURS ViT-B/16 real A3/A4 secure run

- Ablation: **A4**
- Attention packing: **unpacked**
- Structural path validation: **PASS**
- Secure end-to-end: **924.368635 s**
- Under 8 minutes: **FAIL**
- Setup + secure (slower party): **1199.129544 s**
- Communication (Alice + Bob): **32362225988 bytes**
- Head executions: Softmax=72, ReLU=0, Linear=72
- C2M=3940, M2C=5544, conversion ciphertexts=9484
- HE=176.592322 s, conversion=254.307283 s, MPC nonlinear bucket=339.089913 s
- Numerical accuracy: **BLOCKED by paused/failed A0**; matching party predictions are not an accuracy claim.
