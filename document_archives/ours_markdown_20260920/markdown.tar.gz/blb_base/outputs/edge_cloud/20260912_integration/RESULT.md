# ViT-Head Edge/Cloud Integration: Post-Run Analysis

The two GPU-4 jobs completed their full 12-layer secure graphs, with both
parties exiting successfully. Integration equivalence is **FAIL**. The single
paired timing measurement is within the predeclared 5% slowdown threshold,
but predictions and logits do not agree. The historical eight-minute runtime
was not reproduced with its original configuration in this experiment.

The background controller stopped at 13:30 on September 12 because the direct
run failed its clear/fixed reference check. Its failure record is preserved.
This post-run analysis additionally evaluated the integrated reference and
generated `a4_gpu4_comparison.json` and `a4_gpu4_comparison.csv`. Neither
reference verification required GPU execution.

## Implemented Solution

Lamination now provides a task-level launcher with Pencil and ViT-Head native
backends. It manages roles, configuration, public plans, device selection,
lifecycle, artifact bindings and metrics. ViT still runs its complete native
Phantom CKKS / SCI Alice-Bob program; the controller does not execute layers,
relay intermediate ciphertexts or introduce a Pencil BFV context.

This does not implement DATA/PARAM selection inside ViT operators. Model
weights, the selected public head plan and cryptographic kernels were not
modified by the integration. The native two-GPU Docker argument required a
quoting correction. The original HAP configuration was preserved; separate
regression overlays were added. The final completed pair used only GPU 4,
shared by both parties, with GPU 1 excluded.

## Same-Configuration Pair

Both runs used A4, 6 Softmax / 0 ReLU / 6 HE-linear heads per layer, 12 layers,
197 logical / 256 physical tokens, group_packing=0, baseline_attention_packing=1,
fast conversion, 8 GPU streams and 1 Gbps / 0.3 ms RTT. Model, input, head-plan,
native binary, Phantom library, runner hashes, image ID and explicit execution
settings match. Native binary SHA-256:
`c5dc109ffaa30af61351a787a1890f9fd8497d765c5db4b116bdfe0663dd4314`.

| Metric | Direct | Integrated |
| --- | ---: | ---: |
| Secure online, seconds | 908.940727 | 924.368635 |
| Secure online, minutes | 15.1490 | 15.4061 |
| Setup/offline, seconds | 281.260775 | 274.761546 |
| Setup plus secure, minutes | 19.8367 | 19.9855 |
| Whole request wall time, minutes | 20.7794 | 20.9398 |
| Secure predicted class, both parties | 449 | 949 |
| Float64 / fixed-clear predicted class | 248 / 248 | 248 / 248 |
| Secure vs fixed-clear maximum logit error | 16209479.922607 | 15828583.608643 |

Online time increased by 15.427908 seconds (1.69735%). Whole request time
increased by 9.625862 seconds (0.77207%). There is only one pair; this does not
establish a statistically stable overhead estimate or a speed guarantee.

All 1000 logits fail the predeclared elementwise equivalence gate; the maximum
direct/integrated difference is 32013689.882324. These are substantial numerical
failures, not merely a small tolerance overrun. The direct native run already
disagrees with the clear model, so the integration is not required for numerical
failure to occur. A direct/direct repeat and layerwise diagnostics are needed
to establish the source of run-to-run disagreement. No dataset accuracy was
measured or preserved by this single-image test.

Conversion counts and communication rounds match between the paired runs:
3940 CKKS-to-MPC, 5544 MPC-to-CKKS, 9484 converted ciphertexts and 22508 rounds
per party. The strict audit also detects small byte-count differences on Bob
and a rescale-counter difference on Alice (32610 versus 32613). Those
differences alone do not identify the cause of the numerical failure.

## Historical Eight-Minute Record

Source: `Vit-Head/BLB/outputs/vit_b16_blb/gpu_direct_qkv_stream8_full12_gpu1_gpu2_20260830/`.
This is a historical log reference, not a new use of GPU 1.

| Condition | Historical record | Current paired experiment |
| --- | --- | --- |
| Runtime | Original BLB, all Softmax | Current OURS A4, 6S/0R/6L |
| GPUs | Separate A100 GPU 1 and GPU 2 | Shared A100 GPU 4 |
| Binary SHA-256 prefix | f58c1e1e7dec | c5dc109ffaa3 |
| Model/input hashes | Same as current pair | Same as historical record |
| Online time | 498.103927 s = 8.3017 min | 908.94 / 924.37 s |
| Setup plus secure | 780.799229 s = 13.0133 min | 1190.20 / 1199.13 s |
| Online rounds per party | 7824 | 22508 |

The historical eight minutes refers to secure online graph time, excluding
setup and outer launch/reference work. The current direct native run is
already 82.48% slower than that historical online measurement, before the new
controller is involved. Changed runtime, plan/packing and device topology
prevent attributing that entire difference to integration or to a single GPU.

Alice's 12-layer instrumented Softmax bucket rises from 97.4867 s historically
to 267.8889 s in the current direct run; conversion time rises from 48.1128 s
to 244.9331 s. These buckets can overlap and must not be summed into an
additive explanation. They show that execution work differs materially from
the historical fast path. The historical record itself predicted class 705,
so it must not be treated as an independently accepted numerical baseline.

## Acceptance and Next Steps

Task-level integration and full graph execution are verified. Prediction
equivalence, model accuracy and preservation of the historical eight-minute
configuration are not verified. Keep the original fast runtime/model/input
as an explicit baseline; compare its direct and integrated executions on the
same available non-GPU-1 devices. Before a performance claim, establish its
numerical correctness and reproducibility. Run repeated paired measurements
only after those gates pass. No new GPU jobs were launched for this analysis.

## Evidence

- `a4_direct_gpu4_01/task_manifest.json`, `native/execution_totals_party*.csv`,
  `native/reference_report.json`.
- `a4_integrated_gpu4_01/task_manifest.json`, `native/execution_totals_party*.csv`,
  `native/reference_postrun_report.json`.
- `a4_gpu4_comparison.json`: full binding, counter, timing and logit comparison.
- `a4_gpu4_comparison.csv`: concise paired metrics.
- `background_status.json`, `BACKGROUND_FAILURE.txt`: original automation failure.
