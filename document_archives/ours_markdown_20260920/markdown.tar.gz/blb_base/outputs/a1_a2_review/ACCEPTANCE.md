# A1/A2 acceptance snapshot

Date: 2026-08-31. A0 remains `FAIL / PAUSED`; no 12-layer secure experiment
was started.

## A1

| Check | Status | Key evidence |
|---|---|---|
| Typed plan/parser and rejection tests | PASS | `OURS_HETERO_PLAN_TEST status=PASS` |
| Manual three-path public oracle | PASS | Softmax/ReLU/Linear all reached; mixed vs independent execution max-abs 0; padded keys 0 |
| Secure mixed dispatch | PASS | 4 Softmax + 4 ReLU + 4 Linear-surrogate heads; 12 invocations; no private dynamic branch |
| Secure process completion | PASS | Alice rc=0, Bob rc=0 on physical GPUs 2/3 |
| Secure vs heterogeneous fixed-clear | FAIL | secure top-1 585, fixed-clear top-1 447; max-abs 1.715576171875; RMSE 0.5562445472600592 |

The unshaped single-attention-prefix run took 396.087543 s and sent
1,047,453,507 bytes from party 1. It is diagnostic evidence only, not a formal
1 Gbps / 0.3 ms result.

| A1 path (party 1, unshaped) | Heads | Mean/head latency | Sent bytes | Rounds |
|---|---:|---:|---:|---:|
| Softmax MPC | 4 | 50,259.375 ms | 315,873,536 | 1,146 |
| ReLU normalization MPC | 4 | 24,703.528 ms | 163,881,536 | 508 |
| Linear MPC surrogate | 4 | 6,654.112 ms | 27,141,888 | 48 |

## A2

| Check | Status | Key evidence |
|---|---|---|
| Four-sample per-head calibration | PASS | 864 rows = 12 layers × 12 heads × 3 paths × 2 oracles |
| Disturbance definition | PASS | relative-L2 on each attention-head context versus Softmax, for FP32 and fixed-clear |
| Fixed-clear operator match | PASS | ReLU uses the 37-bit SCI division reconstruction; Linear quantizes public alpha before multiply/truncate |
| Offline selector/unit tests | PASS (repaired) | 6 tests; exact group-size cost, no per-head extrapolation, network/topology gate, JSON V2 |
| Inference-time dynamic selection | PASS (absent) | runtime only loads a fixed 144-row public plan before sockets open |
| Formal eligible secure path costs | PASS | exact Softmax-12, Softmax-11, ReLU-1 groups; separate GPUs; 1 Gbps / 0.3 ms |
| Cost-scope isolation | PASS | QKV/CKKS→MPC executed; selector measures normalization only; MPC→CKKS/AV/WO explicitly deferred to A3 |
| Final `head_assignment.json` | PASS / NO-SWITCH | V2 replacement selects 144 Softmax heads from exact group costs |
| Four-sample global guard | PASS | top-1 agreement 1.0; replacement FP32/fixed logit error exactly zero |
| 12-layer reorder oracle | PASS | fixed max-abs 0; FP32 logits max-abs 1.78e-15 |

At a maximum-of-FP32/fixed relative-L2 threshold, ReLU admits 1/144 heads at
0.25, 13/144 at 0.30, 30/144 at 0.35, 55/144 at 0.40, and 84/144 at 0.50.
Linear admits 0/144 heads at 0.50. No threshold was silently relaxed.

The historical 349.999 s Softmax, 159.452 s ReLU, and 42.256 s Linear-surrogate
rows are rejected. They used one physical GPU shared by both parties; Softmax
and ReLU also contained the removed full-MPC division bottleneck. They remain
on disk only as audit evidence and are not accepted by the cost loader.

The repaired runner dynamically requires two distinct idle GPUs. Softmax is
restored to BLB HE-assisted exponentiation/reciprocal; ReLU uses MPC ReLU plus
the same HE-assisted reciprocal. Costs are keyed by exact group head count.
The Linear MPC surrogate is never selection-eligible; a real A4 CKKS row is
required.

The slow wide-ring MPC-to-CKKS implementation and its environment switch were
deleted. The only production implementation is BLB Algorithm 1. The repaired
formal group measurements are:

| Group | Latency | Aggregate communication | Rounds |
|---|---:|---:|---:|
| Softmax-12 | 7.308568 s | 274,439,044 bytes | 226 |
| Softmax-11 | 7.123358 s | 251,569,461 bytes | 226 |
| ReLU-1 | 2.899737 s | 13,485,948 bytes | 184 |
| ReLU-12 | 32.594751 s | 164,561,490 bytes | 186 |
| Linear-12 MPC surrogate (ineligible) | 38.414002 s | 89,667,744 bytes | 12 |

At threshold 0.25 only layer-10 original head 3 admits ReLU; all Linear heads
fail the disturbance limit. The full 11+1 group plan costs 10.023095 s versus
7.308568 s for Softmax-12, so the replacement selector correctly keeps all
144 heads on Softmax. The four calibration inputs are unlabeled, so accuracy
is `null`; the available correctness guard is 4/4 top-1 agreement with zero
logit disturbance. The active estimator is anchored to BLB: 498.104 s E2E
minus 97.486694 s BLB normalization plus 87.702821 s selected normalization,
giving 488.320127 s (8.138669 min), 1.964% faster but not below eight minutes.
Full 12-layer secure execution remains prohibited by the paused/failed A0
gate; the remaining target gap belongs to real A3/A4 work.
