# Packing And Conversion Repair, 2026-09-16

Status: **partial; the 498-second target has NOT been achieved**.
All runtime changes are under OURS. BLB and lamination were not modified.
No full 12-block inference was launched in this repair round.

## Latest Measured Result

Run: `block2_stream_order`, GPUs 4/6, A0 (heterogeneous attention disabled),
full Softmax, 1 Gbps / 0.3 ms RTT, 64 MPC/OMP workers per party, 8 GPU streams.
No intermediate tensors were opened. This is a **two-block prefix followed by
the normal final LayerNorm and classifier**, not the complete model.

| Metric | Result |
| --- | ---: |
| Secure online time | 190.874233 s |
| Block 0 / block 1 online time | 91.797382 / 83.438733 s |
| Setup/offline time, Alice | 215.527170 s |
| Online communication, sum of both parties' sent bytes | 6,080,675,618 bytes |
| Second-block communication, same accounting | 2,716,498,267 bytes |
| Secure / fixed / clear top-1 | 733 / 733 / 733 |
| Logit relative L2 versus fixed | 0.02054343 |
| Maximum absolute logit error versus fixed | 0.01855469 |
| HE rotations, two-block prefix plus classifier | 101,262 |
| CKKS-to-MPC / MPC-to-CKKS ciphertexts | 318 / 510 |

Both parties produced identical logits. The existing fixed numerical gate
passes for this input and prefix. Full-model and dataset accuracy remain
unvalidated, and one passing run does not establish statistical repeatability.

Forecast using first block + 11 times second block + nonblock online work:
**1,025.26 s (17.09 min)**, approximately **33.25 GB aggregate online traffic**.
These are projections, not full-model measurements. The performance gate
against 498.103927 s +/- 5% fails. About 40 s/block, not merely 60 s/block,
would be needed to fit that target after nonblock work.

## What Changed

- Fused centered prime-field conversion removes a redundant comparison while
  retaining the existing SCI/EMP primitives and 40-bit wide-ring margin.
- Real/imaginary pairing exports both adjacent real tensors, not just half
  of the original ciphertext vector. It is applied to QK/V, exp and FFN/GELU
  outputs, including odd batch tails.
- Public masked key columns are compacted for Softmax and restored as zeros.
- Pre-norm residuals are added locally to same-scale MPC shares.
- Existing reciprocal work is partitioned over independent SCI workers.
- QKV/FFN short GPU affine/rescale loops no longer launch unsynchronized work
  on OpenMP workers' CUDA streams before main-thread consumption. Matrix
  kernels retain their explicitly synchronized parallel streams.
- Existing real-coefficient symmetry and inverse-sigma import reuse remain.

The GPU ordering defect was isolated by `trace2`: QK, Softmax, AV and WO stayed
close to a passing trace, while FFN1 was the first large-error stage. That run
was stopped; its later values are not accepted. After the ordering repair,
the no-observation two-block regression above passed. The initial `block1`
and `block2` numerical failures are retained, not hidden or averaged away.

## Original BLB Audit

The packing ideas **do apply to ViT**. However, the repository's original
`BLB/gpu/SCI/tests/bert_large_bolt/ckks_bert.cpp:934` explicitly describes a
first-half transfer as `simulate x+y*j optimization`. Its `linear_ckks.cpp`
also caps QK rotations and omits feature-reduction rotations. Copying those
shortcuts is not equivalent to implementing the packed arithmetic correctly.
This observation is about repository implementations, not the BLB paper.

The historical 498.103927 s run's stored numerical validation reports secure
top-1 705 versus fixed/clear 248. It remains a timing target, not a verified
joint speed/accuracy baseline. Its aggregate online traffic is 15.089586259 GB,
or about 7.545 GB averaged per party. Do not compare today's aggregate total
with a historical single-party or averaged 8 GB figure.

The native edge/cloud dispatcher adds no online messages. The remaining gap
is in conversion and arithmetic work, not Python dispatch or extra edge/cloud
serialization. Reducing thread counts blindly is also unsafe: full-model
LayerNorm still has fixed 64-worker calls. No unsupported thread configuration,
reduced security margin, skipped arithmetic, or heterogeneous substitute was
used to obtain the reported result.

See `assessment.json` for exact metrics, rejected runs and test coverage.
