# P1：证明方法有效（真实运行）

结论：**FAIL**。当前主预算上的 Ours 没有通过 50 张 fixed-clear 模型级精度门禁；同时 Random 没有对应的完整 secure assignment 实测成本，不能用成本外推补齐。

## 实验口径

- calibration：4 张公开输入；relative-L2 threshold=0.65; global calibration guard=True。
- test：固定 50 张 manifest，sha256=d4b500ed21cda1d6f5a6a27e708256af45af23d3a02a6bb80ecb9736fb2b87c9；只报告 fixed-clear accuracy，secure 50 张 accuracy 未运行。
- 成本：只匹配 `direct_assignment_costs_a3_a4_full12_active_20260901.csv` 中同一层、同一完整 Head assignment 的真实 A3/A4 行。表中成本是 12 个已测 block assignment unit 的直接汇总，不是完整网络 latency 预测；没有匹配行就记 N/A。

## P1 主结果

| Method | Head counts | Fixed-clear 50 accuracy | Drop vs All-Softmax | Direct assignment latency sum (s) | Direct communication sum (GB) | Conversion ct | Cost coverage |
|---|---:|---:|---:|---:|---:|---:|---:|
| All-Softmax | 144S / 0R / 0L | 38/50 (76.0%) | +0.0 pp | 511.136 | 7.758 | 10080 | 12/12 direct rows |
| Random | 140S / 0R / 4L | 39/50 (78.0%) | -2.0 pp | N/A | N/A | N/A | N/A |
| Sensitivity-only | 140S / 0R / 4L | 32/50 (64.0%) | +12.0 pp | 510.403 | 7.623 | 9840 | 12/12 direct rows |
| Cost-only | 140S / 0R / 4L | 32/50 (64.0%) | +12.0 pp | 510.403 | 7.623 | 9840 | 12/12 direct rows |
| Ours | 140S / 0R / 4L | 32/50 (64.0%) | +12.0 pp | 510.403 | 7.623 | 9840 | 12/12 direct rows |

## Calibration gate

| Metric | Result | Status |
|---|---:|---|
| 4-image top-1 agreement | 1.000 | PASS |
| FP32 logits max-abs | 2.8590 (limit 4.0) | PASS |
| Fixed logits MSE | 0.2685 (limit 0.30) | PASS |
| Ours 50-image accuracy >= All-Softmax | 32/50 >= 38/50 | FAIL |
| Random/Sensitivity/Cost/Ours same S/R/L count | True | PASS |
| All five secure cost rows directly measured | False | FAIL |
| **P1 method effective** | calibration + accuracy + cost evidence | **FAIL** |

## 失败原因

1. 0.65 阈值生成的 Ours 为 140S/0R/4L；它在 4 张 calibration 图上 top-1 agreement=1.0，但在独立 50 张 fixed-clear 测试上只有 32/50，而 All-Softmax 为 38/50，下降 12.0 个百分点。局部 attention-context relative-L2 没有充分预测模型级分类误差。
2. 本轮每个允许降级层只有一条直接测得的 10S/2L assignment；因此 Cost-only 与 Ours 选到同一固定计划，无法从这批数据证明 cost-aware selector 比 sensitivity-only 更好。
3. Random 的 Head 编号不同，没有对应的完整 A3/A4 secure assignment 行；其 50 张 fixed-clear 数值可以报告，但 secure latency/communication 必须继续实测，不能按 group size 或 Ours 行推算。

## 允许写入论文的结论

本轮只能写：selector 生成了固定、可审计且 calibration guard 通过的计划；不能写“P1 方法有效”。在补足 50 张代表性 calibration/model-level gate、每层多个真实 assignment 成本候选并完成 Random 等 secure 实测前，P1 应保持 FAIL。
