# BLB ViT-B/16 secure inference measurement

Protocol: original BLB CKKS + MPC/VOLE; no protocol substitution.

- Packing: **197 logical tokens → 256 physical rows**
- Executed Transformer blocks: **12**
- Secure end-to-end: **798.473100 s**
- Communication (Alice+Bob): **24524255636 bytes (24.524256 GB)**
- HE internal counter: **130.661483 s**
- Conversion internal counter: **217.041715 s**
- H2D internal counter: **0.475330 s**
- Phantom plaintext encode: **102.519351 s**
- Phantom plaintext release: **0.000000 s**
- D2H internal counter: **0.079055 s**
- MPC nonlinear wall buckets: **176.883943 s**

The nonlinear bucket is diagnostic and overlaps the prescribed HE/conversion boundaries inside LayerNorm; it is not added to the other counters.

| Stage | 12-block wall time (s) | Alice+Bob send bytes |
|---|---:|---:|
| QKV | 39.420271 | 692103951 |
| QK^T | 66.771721 | 0 |
| CKKS_to_MPC | 175.500411 | 6929969184 |
| Softmax | 169.026806 | 4740511302 |
| MPC_to_CKKS | 69.558507 | 2199953696 |
| Softmax_x_V | 68.331725 | 0 |
| Output_Projection | 9.794010 | 75518352 |
| LayerNorm1 | 16.201131 | 1238191360 |
| FFN1 | 49.909649 | 795221738 |
| GELU | 39.383784 | 1718446112 |
| FFN2 | 66.910385 | 830776032 |
| LayerNorm2 | 14.823911 | 1238191360 |

- Full counters: `baseline_summary.csv`
- Per-block counters: `block_profile_alice_plus_bob.csv`
- Per-block stage timeline: `block_online_breakdown_alice_plus_bob.csv`
