# BLB ViT-B/16 secure inference measurement

Protocol: original BLB CKKS + MPC/VOLE; no protocol substitution.

- Packing: **197 logical tokens → 256 physical rows**
- Executed Transformer blocks: **12**
- Secure end-to-end: **800.572104 s**
- Communication (Alice+Bob): **24524255829 bytes (24.524256 GB)**
- HE internal counter: **126.470905 s**
- Conversion internal counter: **220.031614 s**
- H2D internal counter: **0.368078 s**
- Phantom plaintext encode: **101.521809 s**
- Phantom plaintext release: **0.000000 s**
- D2H internal counter: **0.118987 s**
- MPC nonlinear wall buckets: **186.694591 s**

The nonlinear bucket is diagnostic and overlaps the prescribed HE/conversion boundaries inside LayerNorm; it is not added to the other counters.

| Stage | 12-block wall time (s) | Alice+Bob send bytes |
|---|---:|---:|
| QKV | 38.480279 | 692103241 |
| QK^T | 63.574165 | 0 |
| CKKS_to_MPC | 176.460832 | 6929969184 |
| Softmax | 171.144388 | 4740523709 |
| MPC_to_CKKS | 72.903777 | 2199953696 |
| Softmax_x_V | 66.554521 | 0 |
| Output_Projection | 10.082781 | 75518352 |
| LayerNorm1 | 16.866166 | 1238191360 |
| FFN1 | 49.310970 | 795219003 |
| GELU | 41.759277 | 1718446112 |
| FFN2 | 64.669812 | 830776032 |
| LayerNorm2 | 14.592030 | 1238191360 |

- Full counters: `baseline_summary.csv`
- Per-block counters: `block_profile_alice_plus_bob.csv`
- Per-block stage timeline: `block_online_breakdown_alice_plus_bob.csv`
