# BLB ViT-B/16 secure inference measurement

Protocol: original BLB CKKS + MPC/VOLE; no protocol substitution.

- Packing: **197 logical tokens → 256 physical rows**
- Executed Transformer blocks: **12**
- Secure end-to-end: **807.564751 s**
- Communication (Alice+Bob): **24476917426 bytes (24.476917 GB)**
- HE internal counter: **126.802796 s**
- Conversion internal counter: **225.521889 s**
- H2D internal counter: **0.385610 s**
- Phantom plaintext encode: **101.594204 s**
- Phantom plaintext release: **0.000000 s**
- D2H internal counter: **0.079426 s**
- MPC nonlinear wall buckets: **183.842512 s**

The nonlinear bucket is diagnostic and overlaps the prescribed HE/conversion boundaries inside LayerNorm; it is not added to the other counters.

| Stage | 12-block wall time (s) | Alice+Bob send bytes |
|---|---:|---:|
| QKV | 38.518375 | 692105856 |
| QK^T | 64.374756 | 0 |
| CKKS_to_MPC | 180.948793 | 6883962912 |
| Softmax | 170.367827 | 4740506763 |
| MPC_to_CKKS | 73.787776 | 2199953696 |
| Softmax_x_V | 67.357756 | 0 |
| Output_Projection | 10.154093 | 75518352 |
| LayerNorm1 | 16.887436 | 1238191360 |
| FFN1 | 48.675702 | 795218684 |
| GELU | 40.784655 | 1718446112 |
| FFN2 | 67.126683 | 830776032 |
| LayerNorm2 | 14.730830 | 1238191360 |

- Full counters: `baseline_summary.csv`
- Per-block counters: `block_profile_alice_plus_bob.csv`
- Per-block stage timeline: `block_online_breakdown_alice_plus_bob.csv`
