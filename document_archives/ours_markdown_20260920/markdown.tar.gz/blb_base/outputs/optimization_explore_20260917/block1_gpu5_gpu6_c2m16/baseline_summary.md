# BLB ViT-B/16 secure inference measurement

Protocol: original BLB CKKS + MPC/VOLE; no protocol substitution.

- Packing: **197 logical tokens → 256 physical rows**
- Executed Transformer blocks: **1**
- Secure end-to-end: **68.871106 s**
- Communication (Alice+Bob): **5402936660 bytes (5.402937 GB)**
- HE internal counter: **11.152191 s**
- Conversion internal counter: **18.877055 s**
- H2D internal counter: **0.041900 s**
- Phantom plaintext encode: **13.993122 s**
- Phantom plaintext release: **0.000000 s**
- D2H internal counter: **0.005498 s**
- MPC nonlinear wall buckets: **13.536829 s**

The nonlinear bucket is diagnostic and overlaps the prescribed HE/conversion boundaries inside LayerNorm; it is not added to the other counters.

| Stage | 1-block wall time (s) | Alice+Bob send bytes |
|---|---:|---:|
| QKV | 3.472130 | 57674968 |
| QK^T | 5.838417 | 0 |
| CKKS_to_MPC | 15.541700 | 586950656 |
| Softmax | 13.398622 | 385391112 |
| MPC_to_CKKS | 6.204958 | 171627520 |
| Softmax_x_V | 5.497295 | 0 |
| Output_Projection | 0.812761 | 6293196 |
| LayerNorm1 | 1.238756 | 102436672 |
| FFN1 | 4.028945 | 66268325 |
| GELU | 2.818375 | 141572096 |
| FFN2 | 9.004526 | 69231336 |
| LayerNorm2 | 1.014621 | 102436672 |

- Full counters: `baseline_summary.csv`
- Per-block counters: `block_profile_alice_plus_bob.csv`
- Per-block stage timeline: `block_online_breakdown_alice_plus_bob.csv`
