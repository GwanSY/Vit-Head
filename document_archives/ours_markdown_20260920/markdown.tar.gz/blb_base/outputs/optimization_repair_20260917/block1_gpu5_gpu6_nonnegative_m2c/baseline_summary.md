# BLB ViT-B/16 secure inference measurement

Protocol: original BLB CKKS + MPC/VOLE; no protocol substitution.

- Packing: **197 logical tokens → 256 physical rows**
- Executed Transformer blocks: **1**
- Secure end-to-end: **70.248258 s**
- Communication (Alice+Bob): **5415641915 bytes (5.415642 GB)**
- HE internal counter: **13.514897 s**
- Conversion internal counter: **18.274473 s**
- H2D internal counter: **0.037367 s**
- Phantom plaintext encode: **11.296317 s**
- Phantom plaintext release: **0.000000 s**
- D2H internal counter: **0.005160 s**
- MPC nonlinear wall buckets: **13.595383 s**

The nonlinear bucket is diagnostic and overlaps the prescribed HE/conversion boundaries inside LayerNorm; it is not added to the other counters.

| Stage | 1-block wall time (s) | Alice+Bob send bytes |
|---|---:|---:|
| QKV | 4.022883 | 57675298 |
| QK^T | 7.600421 | 0 |
| CKKS_to_MPC | 14.716168 | 598452224 |
| Softmax | 13.231946 | 385392794 |
| MPC_to_CKKS | 6.071731 | 171627520 |
| Softmax_x_V | 5.570486 | 0 |
| Output_Projection | 0.866298 | 6293196 |
| LayerNorm1 | 1.617248 | 102436672 |
| FFN1 | 4.056123 | 66267935 |
| GELU | 2.515328 | 141572096 |
| FFN2 | 8.865145 | 69231336 |
| LayerNorm2 | 1.102081 | 102436672 |

- Full counters: `baseline_summary.csv`
- Per-block counters: `block_profile_alice_plus_bob.csv`
- Per-block stage timeline: `block_online_breakdown_alice_plus_bob.csv`
