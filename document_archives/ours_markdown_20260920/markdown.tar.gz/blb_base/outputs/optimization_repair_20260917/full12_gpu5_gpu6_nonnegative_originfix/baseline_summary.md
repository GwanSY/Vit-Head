# BLB ViT-B/16 secure inference measurement

Protocol: original BLB CKKS + MPC/VOLE; no protocol substitution.

- Packing: **197 logical tokens → 256 physical rows**
- Executed Transformer blocks: **12**
- Secure end-to-end: **833.052745 s**
- Communication (Alice+Bob): **24618878149 bytes (24.618878 GB)**
- HE internal counter: **138.001052 s**
- Conversion internal counter: **231.560887 s**
- H2D internal counter: **0.395322 s**
- Phantom plaintext encode: **107.555550 s**
- Phantom plaintext release: **0.000000 s**
- D2H internal counter: **0.090379 s**
- MPC nonlinear wall buckets: **187.420363 s**

The nonlinear bucket is diagnostic and overlaps the prescribed HE/conversion boundaries inside LayerNorm; it is not added to the other counters.

| Stage | 12-block wall time (s) | Alice+Bob send bytes |
|---|---:|---:|
| QKV | 41.386293 | 692103742 |
| QK^T | 70.546784 | 0 |
| CKKS_to_MPC | 185.134365 | 7021981728 |
| Softmax | 174.409381 | 4740511134 |
| MPC_to_CKKS | 76.200305 | 2199953696 |
| Softmax_x_V | 67.929502 | 0 |
| Output_Projection | 10.276399 | 75518352 |
| LayerNorm1 | 17.245739 | 1238191360 |
| FFN1 | 51.662426 | 795218536 |
| GELU | 41.124455 | 1718446112 |
| FFN2 | 70.641113 | 830776032 |
| LayerNorm2 | 15.096367 | 1238191360 |

- Full counters: `baseline_summary.csv`
- Per-block counters: `block_profile_alice_plus_bob.csv`
- Per-block stage timeline: `block_online_breakdown_alice_plus_bob.csv`
