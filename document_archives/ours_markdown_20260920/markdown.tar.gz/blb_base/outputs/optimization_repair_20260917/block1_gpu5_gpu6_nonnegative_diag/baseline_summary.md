# BLB ViT-B/16 secure inference measurement

Protocol: original BLB CKKS + MPC/VOLE; no protocol substitution.

- Packing: **197 logical tokens → 256 physical rows**
- Executed Transformer blocks: **1**
- Secure end-to-end: **65.061147 s**
- Communication (Alice+Bob): **5415607467 bytes (5.415607 GB)**
- HE internal counter: **11.258619 s**
- Conversion internal counter: **16.791803 s**
- H2D internal counter: **0.023140 s**
- Phantom plaintext encode: **11.372489 s**
- Phantom plaintext release: **0.000000 s**
- D2H internal counter: **0.005193 s**
- MPC nonlinear wall buckets: **11.514866 s**

The nonlinear bucket is diagnostic and overlaps the prescribed HE/conversion boundaries inside LayerNorm; it is not added to the other counters.

| Stage | 1-block wall time (s) | Alice+Bob send bytes |
|---|---:|---:|
| QKV | 3.051642 | 57675453 |
| QK^T | 6.319070 | 0 |
| CKKS_to_MPC | 14.394110 | 598452224 |
| Softmax | 12.661464 | 385393280 |
| MPC_to_CKKS | 4.928147 | 171627520 |
| Softmax_x_V | 5.615255 | 0 |
| Output_Projection | 0.824904 | 6293196 |
| LayerNorm1 | 1.124657 | 102436672 |
| FFN1 | 3.959777 | 66267682 |
| GELU | 2.454512 | 141572096 |
| FFN2 | 8.790725 | 69231336 |
| LayerNorm2 | 0.934470 | 102436672 |

- Full counters: `baseline_summary.csv`
- Per-block counters: `block_profile_alice_plus_bob.csv`
- Per-block stage timeline: `block_online_breakdown_alice_plus_bob.csv`
