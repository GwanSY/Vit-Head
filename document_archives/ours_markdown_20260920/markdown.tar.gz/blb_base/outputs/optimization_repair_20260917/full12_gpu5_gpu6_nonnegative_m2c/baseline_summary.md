# BLB ViT-B/16 secure inference measurement

Protocol: original BLB CKKS + MPC/VOLE; no protocol substitution.

- Packing: **197 logical tokens → 256 physical rows**
- Executed Transformer blocks: **12**
- Secure end-to-end: **784.841247 s**
- Communication (Alice+Bob): **24618918808 bytes (24.618919 GB)**
- HE internal counter: **128.273905 s**
- Conversion internal counter: **214.914924 s**
- H2D internal counter: **0.351773 s**
- Phantom plaintext encode: **100.561400 s**
- Phantom plaintext release: **0.000000 s**
- D2H internal counter: **0.084778 s**
- MPC nonlinear wall buckets: **175.545390 s**

The nonlinear bucket is diagnostic and overlaps the prescribed HE/conversion boundaries inside LayerNorm; it is not added to the other counters.

| Stage | 12-block wall time (s) | Alice+Bob send bytes |
|---|---:|---:|
| QKV | 39.138483 | 692106591 |
| QK^T | 64.531516 | 0 |
| CKKS_to_MPC | 171.746359 | 7021981728 |
| Softmax | 166.390877 | 4740519220 |
| MPC_to_CKKS | 70.916322 | 2199953696 |
| Softmax_x_V | 66.534239 | 0 |
| Output_Projection | 10.353043 | 75518352 |
| LayerNorm1 | 16.035912 | 1238191360 |
| FFN1 | 49.573161 | 795220031 |
| GELU | 40.221281 | 1718446112 |
| FFN2 | 63.724773 | 830776032 |
| LayerNorm2 | 14.008059 | 1238191360 |

- Full counters: `baseline_summary.csv`
- Per-block counters: `block_profile_alice_plus_bob.csv`
- Per-block stage timeline: `block_online_breakdown_alice_plus_bob.csv`
