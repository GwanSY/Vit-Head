# Numerical Repair Audit, 2026-09-16

## Verified Facts

- Historical BLB all-Softmax dual-A100 online maximum: 498.103927 seconds.
  Its own `plain_fixed_secure_validation.json` records clear/fixed Top-1 248,
  secure Top-1 705, and fixed-to-secure max logit error 16723872.146240234.
  A metric row marked PASS there only means the metric was computed.
- The latest completed native edge/cloud run was A4, not disabled
  heterogeneity: 6 Softmax + 6 HE-linear heads, group packing 0, legacy fast
  conversion, GPU 2/3. Online maximum 914.460734 seconds; numerical FAIL.
- A0 dispatch selects `softmax_he` and the legacy attention output operator.
  It never configures A3/A4 heterogeneous groups. The runner now resolves
  shared A4 packing settings to A0 baseline packing when A0 is selected.
- The historical executable hash differs from current OURS. Equal model
  labels alone do not prove equivalent kernels, operation counts or timing.

## Candidate

- `build_02/ours_vit_b16_main`, SHA-256
  `5707c0c9c669a0563ad971d8b8120f943547e8c60b8978b8c4ce8adf97da312c`.
- Explicit `exact` conversion uses existing secure ring extension/scale
  handling. Legacy fast suppresses source-to-target scale reduction and
  retains the legacy local-share FFT; it is preserved only for comparison.
- Exact Softmax row maximum batches independent comparisons per tree level,
  keeping the fork's correct signed predicate and its existing SCI operators.
  At 128 keys, comparison/selection batches decrease from 127 to 7.
- Old kernel archive, original direct/native binaries and Phantom library
  remain unchanged. See `build_02/build_manifest.json` and
  `smoke_04/status.json` for identities.
- Native source edits stay inside OURS. No lamination code was changed.

## Completed Tests

`smoke_04/` completed successfully on GPU 2/3:

| Test | Numeric result | Process exits |
| --- | --- | --- |
| Original fast GPU conversion | Expected FAIL, 16384 bad slots | 0, 1 |
| Candidate exact GPU conversion | PASS, max error 2 raw units, 0 bad slots | 0, 0 |
| Candidate row maximum, real SCI MPC | PASS, 21 shapes, no wrong maxima | 0, 0 |

The fixed-point quantum is 1/4096. These tests use public synthetic inputs;
they are not full-model or dataset-accuracy validation. Three runner
configuration unit tests also passed. Earlier smoke attempts preserve the
diagnostic port self-connection and missing OT-cache-directory failures;
those harness issues were corrected before smoke_04.

## Background Model Verification

UPDATE: Stopped at the user's request during the first direct A0 run.
The queue PID and its inference container have exited; no subsequent run
started. The earlier ETA below is withdrawn. No completed full-model timing
or numerical result is available from this interrupted suite.

`full_suite_01/status.json` is the authoritative live status. The detached
host process started at 10:22:41 CST with PID 2611393, physical GPU 2/3.
Both roles of the first A0 run have started in the GPU backend.

Serial order:

1. Original direct OURS A0, fast, full 12 blocks.
2. Native edge/cloud OURS A0, SAME old kernels/settings, full 12 blocks.
3. Candidate exact A0, one block and final classifier.
4. Candidate exact A0, full 12 blocks, only if the one-block gate passes.
5. Candidate exact A4, one block and final classifier.
6. Candidate exact A4, full 12 blocks, only if the one-block gate passes.

Independent reference gates require fixed/secure Top-1 agreement, relative
L2 <= 0.05 and max absolute logit error <= 0.5. Both parties must publish
identical final logits. These are regression gates, not an accuracy claim.
Legacy fast numerical failures are recorded separately from its timing;
any exact numerical failure stops the queue. Each run checks GPU idleness
again and has a finite six-hour per-party limit.

The A0 timing pair is estimated to finish around 10:55-11:10 CST, depending
on contention. A reliable ETA for the repaired full models needs the first
exact block timing. Neither a completed model-level numerical repair nor
498-second performance of the repaired model is claimed at this point.
