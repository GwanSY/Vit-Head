# OURS ViT-B/16 real A3/A4 secure run

- Ablation: **A3**
- Structural path validation: **PASS**
- Secure end-to-end: **537.982044 s**
- Under 8 minutes: **FAIL**
- Setup + secure (slower party): **800.943315 s**
- Communication (Alice + Bob): **19418110031 bytes**
- Head executions: Softmax=144, ReLU=0, Linear=0
- C2M=5236, M2C=8136, conversion ciphertexts=13372
- HE=158.092153 s, conversion=37.195146 s, MPC nonlinear bucket=163.309541 s
- Numerical accuracy: **BLOCKED by paused/failed A0**; matching party predictions are not an accuracy claim.
