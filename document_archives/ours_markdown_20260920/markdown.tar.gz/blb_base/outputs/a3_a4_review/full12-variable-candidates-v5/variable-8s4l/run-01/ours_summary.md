# OURS ViT-B/16 real A3/A4 secure run

- Ablation: **A4**
- Attention packing: **packed**
- Structural path validation: **PASS**
- Secure end-to-end: **598.541983 s**
- Under 8 minutes: **FAIL**
- Setup + secure (slower party): **958.182516 s**
- Communication (Alice + Bob): **17837161510 bytes**
- Head executions: Softmax=96, ReLU=0, Linear=48
- C2M=4180, M2C=6168, conversion ciphertexts=10348
- HE=188.338782 s, conversion=42.841616 s, MPC nonlinear bucket=175.687113 s
- Numerical accuracy: **BLOCKED by paused/failed A0**; matching party predictions are not an accuracy claim.
