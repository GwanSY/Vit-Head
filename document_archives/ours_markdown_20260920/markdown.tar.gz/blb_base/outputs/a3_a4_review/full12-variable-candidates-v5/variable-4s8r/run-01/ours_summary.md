# OURS ViT-B/16 real A3/A4 secure run

- Ablation: **A3**
- Attention packing: **packed**
- Structural path validation: **PASS**
- Secure end-to-end: **915.353417 s**
- Under 8 minutes: **FAIL**
- Setup + secure (slower party): **1262.270337 s**
- Communication (Alice + Bob): **18520783949 bytes**
- Head executions: Softmax=48, ReLU=96, Linear=0
- C2M=4852, M2C=7752, conversion ciphertexts=12604
- HE=181.353098 s, conversion=49.301413 s, MPC nonlinear bucket=487.603683 s
- Numerical accuracy: **BLOCKED by paused/failed A0**; matching party predictions are not an accuracy claim.
