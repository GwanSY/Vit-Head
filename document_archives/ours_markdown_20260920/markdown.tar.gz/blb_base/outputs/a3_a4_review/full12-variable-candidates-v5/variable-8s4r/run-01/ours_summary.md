# OURS ViT-B/16 real A3/A4 secure run

- Ablation: **A3**
- Attention packing: **packed**
- Structural path validation: **PASS**
- Secure end-to-end: **825.782339 s**
- Under 8 minutes: **FAIL**
- Setup + secure (slower party): **1183.914581 s**
- Communication (Alice + Bob): **18969777934 bytes**
- Head executions: Softmax=96, ReLU=48, Linear=0
- C2M=5044, M2C=7944, conversion ciphertexts=12988
- HE=192.042332 s, conversion=54.267066 s, MPC nonlinear bucket=376.824483 s
- Numerical accuracy: **BLOCKED by paused/failed A0**; matching party predictions are not an accuracy claim.
