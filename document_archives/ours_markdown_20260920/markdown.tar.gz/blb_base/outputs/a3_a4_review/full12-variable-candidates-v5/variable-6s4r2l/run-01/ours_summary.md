# OURS ViT-B/16 real A3/A4 secure run

- Ablation: **A4**
- Attention packing: **packed**
- Structural path validation: **PASS**
- Secure end-to-end: **799.058946 s**
- Under 8 minutes: **FAIL**
- Setup + secure (slower party): **1162.075941 s**
- Communication (Alice + Bob): **18400851714 bytes**
- Head executions: Softmax=72, ReLU=48, Linear=24
- C2M=4588, M2C=6960, conversion ciphertexts=11548
- HE=192.170654 s, conversion=51.982568 s, MPC nonlinear bucket=356.582023 s
- Numerical accuracy: **BLOCKED by paused/failed A0**; matching party predictions are not an accuracy claim.
