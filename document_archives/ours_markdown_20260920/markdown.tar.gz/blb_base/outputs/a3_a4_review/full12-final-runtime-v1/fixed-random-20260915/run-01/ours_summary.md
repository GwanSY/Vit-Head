# OURS ViT-B/16 real A3/A4 secure run

- Ablation: **A4**
- Attention packing: **packed**
- Structural path validation: **PASS**
- Secure end-to-end: **655.987438 s**
- Under 8 minutes: **FAIL**
- Setup + secure (slower party): **957.809562 s**
- Communication (Alice + Bob): **17379392604 bytes**
- Head executions: Softmax=48, ReLU=48, Linear=48
- C2M=3988, M2C=5976, conversion ciphertexts=9964
- HE=161.664806 s, conversion=35.101561 s, MPC nonlinear bucket=287.764851 s
- Numerical accuracy: **BLOCKED by paused/failed A0**; matching party predictions are not an accuracy claim.
