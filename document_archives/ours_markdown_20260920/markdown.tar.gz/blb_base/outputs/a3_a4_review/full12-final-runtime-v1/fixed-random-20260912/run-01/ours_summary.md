# OURS ViT-B/16 real A3/A4 secure run

- Ablation: **A4**
- Attention packing: **packed**
- Structural path validation: **PASS**
- Secure end-to-end: **830.787517 s**
- Under 8 minutes: **FAIL**
- Setup + secure (slower party): **1274.422601 s**
- Communication (Alice + Bob): **17379398270 bytes**
- Head executions: Softmax=48, ReLU=48, Linear=48
- C2M=3988, M2C=5976, conversion ciphertexts=9964
- HE=217.344952 s, conversion=68.537816 s, MPC nonlinear bucket=338.299957 s
- Numerical accuracy: **BLOCKED by paused/failed A0**; matching party predictions are not an accuracy claim.
