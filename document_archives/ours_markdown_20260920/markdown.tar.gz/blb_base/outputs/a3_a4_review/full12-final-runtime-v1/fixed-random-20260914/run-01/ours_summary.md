# OURS ViT-B/16 real A3/A4 secure run

- Ablation: **A4**
- Attention packing: **packed**
- Structural path validation: **PASS**
- Secure end-to-end: **655.265123 s**
- Under 8 minutes: **FAIL**
- Setup + secure (slower party): **1010.408524 s**
- Communication (Alice + Bob): **17379345098 bytes**
- Head executions: Softmax=48, ReLU=48, Linear=48
- C2M=3988, M2C=5976, conversion ciphertexts=9964
- HE=158.679217 s, conversion=36.849089 s, MPC nonlinear bucket=289.668476 s
- Numerical accuracy: **BLOCKED by paused/failed A0**; matching party predictions are not an accuracy claim.
