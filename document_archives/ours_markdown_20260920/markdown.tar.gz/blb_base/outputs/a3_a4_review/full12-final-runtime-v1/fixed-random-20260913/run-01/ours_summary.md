# OURS ViT-B/16 real A3/A4 secure run

- Ablation: **A4**
- Attention packing: **packed**
- Structural path validation: **PASS**
- Secure end-to-end: **1111.950336 s**
- Under 8 minutes: **FAIL**
- Setup + secure (slower party): **1485.062845 s**
- Communication (Alice + Bob): **17379390870 bytes**
- Head executions: Softmax=48, ReLU=48, Linear=48
- C2M=3988, M2C=5976, conversion ciphertexts=9964
- HE=318.998801 s, conversion=81.809757 s, MPC nonlinear bucket=390.977170 s
- Numerical accuracy: **BLOCKED by paused/failed A0**; matching party predictions are not an accuracy claim.
