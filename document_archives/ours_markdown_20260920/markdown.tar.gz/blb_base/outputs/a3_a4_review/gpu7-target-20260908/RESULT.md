# A4 GPU 7 target verification — 2026-09-08

Result: the original parameter-mismatch failure was reproduced, fixed, and the same complete transformer block passed.

- Target: A4, train_6S0R6L, unpacked (`OURS_VIT_GROUP_PACKING=0`), `BLB_VIT_GPU_DIRECT_PLAINTEXT=0`, block limit 1, existing checkpoint/input/reorder binding.
- GPU: physical 7, UUID `GPU-e2323d32-0bbf-5fc6-0132-92daa03b165e`. Docker exposed only device 7; both parties selected this UUID. Both processes were observed on this GPU and had exited after the run. Compilation used no GPU.
- Before: `reproduce/alice.log` ends with `encrypted1 and encrypted2 parameter mismatch`; `reproduce/status.txt` records Alice 2, Bob 143.
- Fix: `ours_vit_b16/runtime/ckks_bert.cpp` consumes the extra public modulus level only for fast diagonal reuse. Full diagonal packing consumes its own selector level; the active packed QK and V operands are then aligned to their actual common level before AV.
- After: `fixed/alice.log` records `OURS_A4_AV_LEVEL status=PASS ... coeff_modulus_size=2`, `OURS_A4_NATIVE_CKKS status=PASS`, and attention-output PASS. AV, W_O, and FFN completed. `fixed/status.txt`: Alice 0, Bob 0.
- Completed block online latency: 161.423723 s. This is a shared-GPU verification run, not a comparative performance benchmark.
- Scope: the original failing one-block target only. The runtime's `PARTIAL executed_blocks=1` is the requested block stop; this does not establish full 12-block completion or numerical accuracy.
- Re-run: `bash outputs/a3_a4_review/gpu7-target-20260908/run_fixed.sh` from the host (Docker access required). It mounts the rebuilt executable and its Phantom library over the existing runtime image; the old image itself is unchanged.
- Executable: `build/container-gpu/bin/ours_vit_b16_main`, SHA-256 `fcd050cf64ec247afd9220c6fa27d10fa4feb18afc194bdf87fa0513095ee795`.
- Validation: target build succeeded; source diff whitespace check passed. No additional smoke tests or combination sweeps were run.
