# OURS ViT-B/16 real A3/A4 secure run

- Ablation: **A3**
- Structural path validation: **PASS**
- Secure end-to-end: **734.706231 s**
- Under 8 minutes: **FAIL**
- Setup + secure (slower party): **998.218452 s**
- Communication (Alice + Bob): **19418116427 bytes**
- Head executions: Softmax=144, ReLU=0, Linear=0
- C2M=5236, M2C=8136, conversion ciphertexts=13372
- HE=352.784752 s, conversion=34.974670 s, MPC nonlinear bucket=165.691649 s
- Numerical accuracy: **BLOCKED by paused/failed A0**; matching party predictions are not an accuracy claim.
