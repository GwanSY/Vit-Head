# BLB ViT-B/16 secure inference measurement

Protocol: original BLB CKKS + MPC/VOLE; no protocol substitution.

- Packing: **197 logical tokens → 256 physical rows**
- Executed Transformer blocks: **12**
- Secure end-to-end: **734.706231 s**
- Communication (Alice+Bob): **19418116427 bytes (19.418116 GB)**
- HE internal counter: **352.784752 s**
- Conversion internal counter: **34.974670 s**
- H2D internal counter: **0.435465 s**
- Phantom plaintext encode: **97.649121 s**
- Phantom plaintext release: **0.000000 s**
- D2H internal counter: **0.303131 s**
- MPC nonlinear wall buckets: **165.691649 s**

The nonlinear bucket is diagnostic and overlaps the prescribed HE/conversion boundaries inside LayerNorm; it is not added to the other counters.

| Stage | 12-block wall time (s) | Alice+Bob send bytes |
|---|---:|---:|
| QKV | 47.296791 | 1384222631 |
| QK^T | 130.278384 | 0 |
| CKKS_to_MPC | 16.612265 | 81494016 |
| Softmax | 177.350398 | 5761745516 |
| MPC_to_CKKS | 25.949255 | 550887936 |
| Softmax_x_V | 117.328616 | 0 |
| Output_Projection | 10.031490 | 75518352 |
| LayerNorm1 | 20.195898 | 1229799520 |
| FFN1 | 60.162781 | 1591118190 |
| GELU | 25.446706 | 1644045152 |
| FFN2 | 77.141469 | 1963209024 |
| LayerNorm2 | 20.544277 | 1255534496 |

- Full counters: `baseline_summary.csv`
- Per-block counters: `block_profile_alice_plus_bob.csv`
- Per-block stage timeline: `block_online_breakdown_alice_plus_bob.csv`
