# OURS ViT-B/16 real A3/A4 secure run

- Ablation: **A4**
- Structural path validation: **PASS**
- Secure end-to-end: **524.749614 s**
- Under 8 minutes: **FAIL**
- Setup + secure (slower party): **794.003233 s**
- Communication (Alice + Bob): **18870964236 bytes**
- Head executions: Softmax=120, ReLU=0, Linear=24
- C2M=4780, M2C=7152, conversion ciphertexts=11932
- HE=162.729541 s, conversion=34.357226 s, MPC nonlinear bucket=150.774348 s
- Numerical accuracy: **BLOCKED by paused/failed A0**; matching party predictions are not an accuracy claim.
