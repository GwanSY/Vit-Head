# OURS ViT-B/16 real A3/A4 secure run

- Ablation: **A3**
- Attention packing: **packed**
- Structural path validation: **PASS**
- Secure end-to-end: **5897.443067 s**
- Under 8 minutes: **FAIL**
- Setup + secure (slower party): **6275.630884 s**
- Communication (Alice + Bob): **134645204977 bytes**
- Head executions: Softmax=144, ReLU=0, Linear=0
- C2M=2932, M2C=3528, conversion ciphertexts=6460
- HE=220.231779 s, conversion=1280.914498 s, MPC nonlinear bucket=4090.216643 s
- Numerical accuracy: **BLOCKED by paused/failed A0**; matching party predictions are not an accuracy claim.
