# BLB ViT-B/16 secure inference measurement

Protocol: original BLB CKKS + MPC/VOLE; no protocol substitution.

- Packing: **197 logical tokens → 256 physical rows**
- Executed Transformer blocks: **12**
- Secure end-to-end: **726.316680 s**
- Communication (Alice+Bob): **18870953594 bytes (18.870954 GB)**
- HE internal counter: **369.021237 s**
- Conversion internal counter: **32.965640 s**
- H2D internal counter: **0.330130 s**
- Phantom plaintext encode: **102.972139 s**
- Phantom plaintext release: **0.000000 s**
- D2H internal counter: **0.237957 s**
- MPC nonlinear wall buckets: **148.829766 s**

The nonlinear bucket is diagnostic and overlaps the prescribed HE/conversion boundaries inside LayerNorm; it is not added to the other counters.

| Stage | 12-block wall time (s) | Alice+Bob send bytes |
|---|---:|---:|
| QKV | 49.981487 | 1472276121 |
| QK^T | 149.594730 | 0 |
| CKKS_to_MPC | 16.380971 | 77377536 |
| Softmax | 149.297968 | 4876577512 |
| MPC_to_CKKS | 23.507424 | 459977408 |
| Softmax_x_V | 112.172625 | 0 |
| Output_Projection | 19.459260 | 151036704 |
| LayerNorm1 | 21.089889 | 1270080352 |
| FFN1 | 59.492858 | 1591117857 |
| GELU | 24.249795 | 1646282976 |
| FFN2 | 75.168285 | 1963209024 |
| LayerNorm2 | 18.864585 | 1229799520 |

- Full counters: `baseline_summary.csv`
- Per-block counters: `block_profile_alice_plus_bob.csv`
- Per-block stage timeline: `block_online_breakdown_alice_plus_bob.csv`
