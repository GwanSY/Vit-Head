# OURS ViT-B/16 real A3/A4 secure run

- Ablation: **A4**
- Structural path validation: **PASS**
- Secure end-to-end: **726.316680 s**
- Under 8 minutes: **FAIL**
- Setup + secure (slower party): **1011.935539 s**
- Communication (Alice + Bob): **18870953594 bytes**
- Head executions: Softmax=120, ReLU=0, Linear=24
- C2M=4780, M2C=7152, conversion ciphertexts=11932
- HE=369.021237 s, conversion=32.965640 s, MPC nonlinear bucket=148.829766 s
- Numerical accuracy: **BLOCKED by paused/failed A0**; matching party predictions are not an accuracy claim.
