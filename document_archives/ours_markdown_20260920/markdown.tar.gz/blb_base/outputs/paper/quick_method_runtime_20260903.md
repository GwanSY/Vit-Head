# Quick P1 method runtime cohort

Scope: one fixed image, block 0 only, same input/model/image binary/GPU cohort, 1Gbps/0.3ms RTT, packed. Latency is the slower party; communication is the sum of both parties. Accuracy fields are NA by design for this runtime-only cohort.

| method | heads | online s | total s | online comm (both) | total comm (both) | rounds | conversion cts | HE rotations | accuracy 50+ | accuracy drop | top-1 agreement |
|---|---|---|---|---|---|---|---|---|---|---|---|
| All-Softmax | 12S+0R+0L | 56.552 | 347.249 | 1,326,739,322 | 4,940,649,651 | 663 | 1128 | 5268 | NA | NA | NA |
| Sensitivity-only | 4S+4R+4L | 71.094 | 377.605 | 1,140,917,298 | 4,994,140,452 | 861 | 844 | 5416 | NA | NA | NA |
| Cost-only | 4S+4R+4L | 68.216 | 388.028 | 1,140,917,882 | 4,994,195,439 | 861 | 844 | 5416 | NA | NA | NA |
| Random-20260903 | 4S+4R+4L | 67.713 | 369.913 | 1,140,913,605 | 4,994,142,757 | 861 | 844 | 5416 | NA | NA | NA |
| Ours | 4S+4R+4L | 71.928 | 370.304 | 1,140,918,855 | 4,994,105,593 | 861 | 844 | 5416 | NA | NA | NA |

## Provenance

- image_id: `sha256:6368d4c1f510d87a9eb6b43fe5cad62f2e67f00af1c271aba94bdac8e6af607a`
- binary_sha256: `ecc7af46323e17b1319b0aab98092a48835f8b3235995ea7f109d8636f18bd5d`
- model_sha256: `c980c11a8478f3ef172fa1121fc87eb02141ad8d8934953ed0323c60fe7d4715`
- input_sha256: `9451755cef0fc6319e0a5869ff7dc9ddecf983f809ba5bf7fee9a6cd80eb431b`
- physical_gpus: `0,1`
- Cost-only is provisional: group-level path-cost ordering plus original-head tie-break.
- All-Softmax is a reference row; it is not the same-count 4S+4R+4L budget.

Run directories:

- All-Softmax: `/home/dm/mind/Vit-Head/OURS/blb_base/outputs/a3_a4_review/restore_old_probe_20260903`
- Sensitivity-only: `/home/dm/mind/Vit-Head/OURS/blb_base/outputs/a3_a4_review/quick_method_runtime_20260903/sensitivity_only`
- Cost-only: `/home/dm/mind/Vit-Head/OURS/blb_base/outputs/a3_a4_review/quick_method_runtime_20260903/cost_only`
- Random-20260903: `/home/dm/mind/Vit-Head/OURS/blb_base/outputs/a3_a4_review/quick_method_runtime_20260903/random_20260903`
- Ours: `/home/dm/mind/Vit-Head/OURS/blb_base/outputs/a3_a4_review/quick_method_runtime_20260903/ours`
