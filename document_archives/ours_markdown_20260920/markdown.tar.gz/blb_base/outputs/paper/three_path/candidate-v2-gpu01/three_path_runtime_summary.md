# Three head-path runtime curve

Direct columns are the requested path marker from each real one-block A4 run; full-block columns are the complete secure block for context. Same GPU/model/input/network cohort.

| path | group | composition | direct online s | direct comm (both) | direct rounds | direct conversion cts | full block online s | full block total s | full block rounds | full block conversion cts |
|---|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Softmax | 1 | 1S+11R | 22.510 | 246,946,808 | 1792 | 8 | 319.513 | 590.718 | 2613 | 220 |
| Softmax | 2 | 2S+10R | 49.121 | 493,853,856 | 1794 | 16 | 307.666 | 588.471 | 2617 | 208 |
| Softmax | 4 | 4S+8R | 104.226 | 1,024,041,717 | 1800 | 32 | 336.479 | 607.850 | 2619 | 224 |
| Softmax | 6 | 6S+6R | 133.674 | 1,518,423,751 | 1798 | 48 | 337.513 | 580.216 | 2613 | 240 |
| Softmax | 8 | 8S+4R | 165.524 | 2,048,045,694 | 1802 | 64 | 357.718 | 586.726 | 2617 | 256 |
| Softmax | 12 | 12S+0R | 345.377 | 3,037,371,093 | 1804 | 96 | 451.930 | 756.859 | 2315 | 288 |
| ReLU | 1 | 11S+1R | 13.446 | 42,412,368 | 192 | 0 | 291.760 | 540.147 | 2617 | 300 |
| ReLU | 2 | 10S+2R | 40.816 | 84,823,440 | 196 | 0 | 433.489 | 676.747 | 2619 | 272 |
| ReLU | 4 | 8S+4R | 60.946 | 169,645,584 | 196 | 0 | 372.600 | 631.178 | 2617 | 256 |
| ReLU | 6 | 6S+6R | 73.676 | 254,467,728 | 196 | 0 | 286.417 | 535.064 | 2613 | 240 |
| ReLU | 8 | 4S+8R | 125.540 | 339,289,872 | 200 | 0 | 329.013 | 618.558 | 2619 | 224 |
| ReLU | 12 | 0S+12R | 171.610 | 508,374,704 | 202 | 0 | 274.954 | 554.617 | 713 | 192 |
| Linear | 1 | 11S+1L | 1.579 | 0 | 0 | 0 | 347.919 | 621.647 | 2329 | 292 |
| Linear | 2 | 10S+2L | 1.624 | 0 | 0 | 0 | 328.260 | 598.825 | 2327 | 264 |
| Linear | 4 | 8S+4L | 2.274 | 0 | 0 | 0 | 280.942 | 557.298 | 2325 | 228 |
| Linear | 6 | 6S+6L | 2.969 | 0 | 0 | 0 | 244.938 | 516.449 | 2323 | 192 |
| Linear | 8 | 4S+8L | 3.582 | 0 | 0 | 0 | 165.844 | 449.613 | 2321 | 156 |
| Linear | 12 | 0S+12L | 4.908 | 0 | 0 | 0 | 46.647 | 333.179 | 413 | 72 |

Provenance:

- image_id: `sha256:541cbeb5c52f65964655ea6cf609f7fa3b5e9ba9c7c4721cdb1394a973d00478`
- binary_sha256: `4a0515dd569844dd927392fb222d905b94406fe17716ee0aa160ca173ae536ef`
- model_sha256: `c980c11a8478f3ef172fa1121fc87eb02141ad8d8934953ed0323c60fe7d4715`
- input_sha256: `9451755cef0fc6319e0a5869ff7dc9ddecf983f809ba5bf7fee9a6cd80eb431b`
- communication columns sum both parties; latency uses the slower party.
