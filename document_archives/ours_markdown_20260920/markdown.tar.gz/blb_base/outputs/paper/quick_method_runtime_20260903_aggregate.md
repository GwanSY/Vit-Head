# Quick P1 method runtime aggregate

One fixed input, block 0, packed, same GPU/model/input/image binary and 1Gbps/0.3ms RTT. Values are mean ± sample std; n=1 rows have std=NA. Latency uses the slower party and communication sums both parties. Accuracy is NA because this is runtime-only.

| method | n | heads | online s mean±std | total s mean±std | online comm mean±std | total comm mean±std | rounds mean±std | conversion cts mean±std | online reduction vs AllS |
|---|---:|---|---:|---:|---:|---:|---:|---:|---:|
| All-Softmax | 1 | 12S+0R+0L | 56.552 ± NA | 347.249 ± NA | 1,326,739,322.00 ± NA | 4,940,649,651.00 ± NA | 663.000 ± NA | 1128.000 ± NA | 0.00% |
| Sensitivity-only | 1 | 4S+4R+4L | 71.094 ± NA | 377.605 ± NA | 1,140,917,298.00 ± NA | 4,994,140,452.00 ± NA | 861.000 ± NA | 844.000 ± NA | -25.72% |
| Cost-only | 1 | 4S+4R+4L | 68.216 ± NA | 388.028 ± NA | 1,140,917,882.00 ± NA | 4,994,195,439.00 ± NA | 861.000 ± NA | 844.000 ± NA | -20.63% |
| Random | 5 | 4S+4R+4L | 68.731 ± 1.530 | 374.396 ± 6.953 | 1,140,916,180.60 ± 2,179.60 | 4,994,112,765.00 ± 23,921.30 | 861.000 ± 0.000 | 844.000 ± 0.000 | -21.54% |
| Ours | 1 | 4S+4R+4L | 71.928 ± NA | 370.304 ± NA | 1,140,918,855.00 ± NA | 4,994,105,593.00 ± NA | 861.000 ± NA | 844.000 ± NA | -27.19% |

The All-Softmax row is a reference with 12S; the other rows are the same-count 4S+4R+4L cohort. Cost-only is provisional because its assignment uses group-level cost ordering plus an explicit original-head tie-break.
